import io
import json
from fastapi.testclient import TestClient
from app.main import app
from app.core.database import Base, engine

Base.metadata.create_all(bind=engine)
client = TestClient(app)


def test_health_and_dashboard():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

    dash = client.get("/api/v1/dashboard")
    assert dash.status_code == 200
    data = dash.json()
    assert "counts" in data
    assert "automation" in data
    assert isinstance(data["automation"]["daily_time_slots"], list)


def test_connect_any_drive_and_youtube_inside_app():
    # Connect first Drive account
    r1 = client.post(
        "/api/v1/accounts/connect-quick",
        data={
            "purpose": "drive",
            "email": "my.first.drive@gmail.com",
            "display_name": "First Drive Account",
        },
    )
    assert r1.status_code == 200
    assert r1.json()["email"] == "my.first.drive@gmail.com"

    # Connect a second Drive account to verify user can connect ANY Drive
    r2 = client.post(
        "/api/v1/accounts/connect-quick",
        data={
            "purpose": "drive",
            "email": "second.backup.drive@gmail.com",
            "display_name": "Second Drive Account",
        },
    )
    assert r2.status_code == 200

    # Connect YouTube Channel account
    r3 = client.post(
        "/api/v1/accounts/connect-quick",
        data={
            "purpose": "youtube",
            "email": "my.youtube.channel@gmail.com",
            "display_name": "My Creator Account",
            "channel_title": "YT AutoPilot Creator Hub",
        },
    )
    assert r3.status_code == 200

    dash = client.get("/api/v1/dashboard").json()
    drive_emails = [a["email"] for a in dash["drive_accounts"]]
    assert "my.first.drive@gmail.com" in drive_emails
    assert "second.backup.drive@gmail.com" in drive_emails
    assert dash["youtube_channel"]["title"] == "YT AutoPilot Creator Hub"


def test_drive_auto_download_and_multi_time_slot_youtube_schedule():
    # Configure custom daily posting times (e.g., 10:00, 14:30, 19:00, 22:15)
    slots = ["10:00", "14:30", "19:00", "22:15"]
    auto_res = client.put(
        "/api/v1/automation",
        json={
            "preset_mode": "Full Auto",
            "daily_time_slots": slots,
            "default_timezone": "Asia/Karachi",
            "daily_upload_limit": 4,
        },
    )
    assert auto_res.status_code == 200
    assert auto_res.json()["daily_time_slots"] == slots

    # Scan Drive folder -> Auto-download -> Auto-generate SEO & Thumbnail -> Auto-Schedule on YouTube
    scan_res = client.post("/api/v1/drive/scan?auto_schedule_after_download=true")
    assert scan_res.status_code == 200
    scan_data = scan_res.json()
    assert scan_data["success"] is True
    assert scan_data["downloaded_count"] >= 1
    assert scan_data["scheduled_count"] >= 1

    # Verify duplicate scan does not re-download the same Drive videos
    scan_again = client.post("/api/v1/drive/scan?auto_schedule_after_download=true")
    assert scan_again.status_code == 200
    assert scan_again.json()["downloaded_count"] == 0

    # Verify scheduled videos have SEO, Thumbnail, and assigned time slots from ["10:00", "14:30", "19:00", "22:15"]
    sch_res = client.get("/api/v1/schedules")
    assert sch_res.status_code == 200
    schedules = sch_res.json()["schedules"]
    assert len(schedules) >= 3
    for item in schedules:
        assert item["seo"] is not None
        assert item["thumbnail"] is not None
        assert item["schedule"]["slot_time_label"] in slots
        assert item["status"] == "scheduled"


def test_upload_client_secret_json_and_encryption():
    sample_client_secret = {
        "installed": {
            "client_id": "1234567890-testapp.apps.googleusercontent.com",
            "client_secret": "GOCSPX-TestSecretValue987654",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
        }
    }
    file_bytes = json.dumps(sample_client_secret).encode("utf-8")
    res = client.post(
        "/api/v1/credentials/upload-client-secret",
        files={"file": ("client_secret.json", io.BytesIO(file_bytes), "application/json")},
    )
    assert res.status_code == 200
    data = res.json()
    assert data["google_oauth_configured"] is True
    assert data["google_client_id"] == "1234567890-testapp.apps.googleusercontent.com"
    assert "••••" in data["google_client_secret_masked"]

    # Verify OAuth URL generation now works with uploaded client_secret.json
    oauth_res = client.get("/api/v1/oauth/url?purpose=drive")
    assert oauth_res.status_code == 200
    assert oauth_res.json()["configured"] is True
    assert "accounts.google.com" in oauth_res.json()["auth_url"]


def test_drive_link_package_and_metadata_parser():
    from app.services.drive_package_parser import (
        extract_drive_folder_id,
        parse_drive_metadata_text,
    )

    fid = extract_drive_folder_id(
        "https://drive.google.com/drive/folders/1XyZ_DrivePackage99?usp=sharing"
    )
    assert fid == "1XyZ_DrivePackage99"

    parsed = parse_drive_metadata_text(
        """
        Title: Amazing AI Video Tutorial 2026
        Description:
        Full walkthrough in Hindi and English.
        Subscribe for more!
        Tags: ai, youtube automation, tutorial
        Hashtags: #ai #youtube #hindi
        """
    )
    assert parsed["seo_title"] == "Amazing AI Video Tutorial 2026"
    assert "Full walkthrough" in parsed["description"]
    assert "youtube automation" in parsed["tags"]
    assert "#ai" in parsed["hashtags"]

    import time
    unique_fid = f"1XyZ_DrivePkg_{int(time.time())}"
    res = client.post(
        "/api/v1/schedules/from-drive-link",
        data={
            "drive_link": f"https://drive.google.com/drive/folders/{unique_fid}?usp=sharing",
            "timezone_str": "Asia/Karachi",
            "privacy_status": "public",
        },
    )
    assert res.status_code == 200
    data = res.json()
    assert data["success"] is True
    assert data["folder_id"] == unique_fid
    assert data["downloaded_count"] >= 1
    assert data["scheduled_count"] >= 1

