from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from apscheduler.schedulers.background import BackgroundScheduler

from app.core.config import settings
from app.core.database import Base, engine, SessionLocal
from app.api.routes import router as api_router
from app.models.models import DriveFolder, GoogleAccount, YouTubeChannel
from app.services.scheduler_service import (
    get_or_create_automation_settings,
    run_full_drive_to_youtube_autopilot,
)


def _background_autopilot_tick():
    db = SessionLocal()
    try:
        cfg = get_or_create_automation_settings(db)
        if cfg.engine_state == "RUNNING":
            run_full_drive_to_youtube_autopilot(db)
    except Exception:
        pass
    finally:
        db.close()


def _seed_initial_workspace():
    db = SessionLocal()
    try:
        get_or_create_automation_settings(db)
        if db.query(DriveFolder).count() == 0:
            folder = DriveFolder(
                folder_id="drive_folder_daily_shorts",
                folder_name="YouTube Daily Videos (Auto-Upload)",
                account_email="Connect any Drive in Drive Tab",
                auto_scan=True,
                auto_download=True,
                auto_schedule=True,
            )
            db.add(folder)
            db.commit()
    finally:
        db.close()


scheduler = BackgroundScheduler()


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    _seed_initial_workspace()
    scheduler.add_job(
        _background_autopilot_tick,
        "interval",
        minutes=5,
        id="drive_to_youtube_autopilot",
        replace_existing=True,
    )
    scheduler.start()
    yield
    scheduler.shutdown(wait=False)


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Personal Google Drive to YouTube Auto-Downloader, AI SEO & Multi-Time-Slot Video Scheduler",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from pathlib import Path
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

app.include_router(api_router, prefix="/api/v1")

WEB_DIST_DIR = Path(__file__).resolve().parent.parent.parent / "desktop" / "dist"
if (WEB_DIST_DIR / "assets").exists():
    app.mount(
        "/assets",
        StaticFiles(directory=str(WEB_DIST_DIR / "assets")),
        name="web_assets",
    )


@app.get("/")
def serve_web_app():
    index_file = WEB_DIST_DIR / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    return {
        "app": settings.APP_NAME,
        "status": "running",
        "message": "Web UI not built yet. Run npm run build in desktop/.",
    }


@app.get("/health")
def health_check():
    return {"status": "ok", "app": settings.APP_NAME, "version": settings.APP_VERSION}
