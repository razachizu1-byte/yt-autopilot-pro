import json
import shutil
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from pathlib import Path
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Query
from fastapi.responses import HTMLResponse, FileResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.config import settings, VIDEOS_DIR, THUMBNAILS_DIR
from app.core.security import encrypt_secret, decrypt_secret, mask_secret
from app.models.models import (
    AppCredential,
    GoogleAccount,
    YouTubeChannel,
    DriveFolder,
    Video,
    SEOMetadata,
    Thumbnail,
    Schedule,
    AutomationSettings,
    ActivityLog,
)
from app.schemas.schemas import (
    CredentialUpdateRequest,
    DriveFolderCreateRequest,
    SEOMetadataUpdateRequest,
    SEOGenerateRequest,
    ThumbnailGenerateRequest,
    ScheduleCreateRequest,
    AutoSlotScheduleRequest,
    AutomationSettingsUpdateRequest,
)
from app.services.media_service import inspect_video_file, create_sample_mp4
from app.services.ai_seo_service import generate_seo_for_video
from app.services.thumbnail_service import generate_youtube_thumbnail
from app.services.google_service import (
    build_google_oauth_url,
    handle_oauth_callback,
    browse_google_drive_folders,
    scan_and_download_drive_folder,
    upload_or_schedule_video_to_youtube,
    log_event,
)
from app.services.scheduler_service import (
    get_or_create_automation_settings,
    ensure_video_has_seo_and_thumbnail,
    schedule_single_video,
    auto_schedule_videos_into_time_slots,
    run_full_drive_to_youtube_autopilot,
)

router = APIRouter()


def serialize_video(v: Video) -> dict:
    seo_dict = None
    if v.seo:
        seo_dict = {
            "seo_title": v.seo.seo_title,
            "alternative_titles": json.loads(v.seo.alternative_titles_json or "[]"),
            "description": v.seo.description,
            "tags": json.loads(v.seo.tags_json or "[]"),
            "keywords": json.loads(v.seo.keywords_json or "[]"),
            "hashtags": json.loads(v.seo.hashtags_json or "[]"),
            "category_id": v.seo.category_id,
            "playlist_id": v.seo.playlist_id,
            "playlist_name": v.seo.playlist_name,
            "language": v.seo.language,
            "ai_model_used": v.seo.ai_model_used,
            "is_approved": v.seo.is_approved,
        }

    thumb_dict = None
    if v.thumbnail:
        thumb_dict = {
            "file_path": v.thumbnail.file_path,
            "image_url": f"/api/v1/media/thumbnail/{v.id}?t={int(v.thumbnail.updated_at.timestamp()) if v.thumbnail.updated_at else 1}",
            "headline_text": v.thumbnail.headline_text,
            "subheadline_text": v.thumbnail.subheadline_text,
            "badge_text": v.thumbnail.badge_text,
            "accent_color": v.thumbnail.accent_color,
            "template_style": v.thumbnail.template_style,
            "uploaded_to_youtube": v.thumbnail.uploaded_to_youtube,
        }

    sch_dict = None
    if v.schedule:
        dt_utc = v.schedule.scheduled_publish_at
        if dt_utc and dt_utc.tzinfo is None:
            dt_utc = dt_utc.replace(tzinfo=timezone.utc)
        tz_name = v.schedule.timezone or "Asia/Karachi"
        try:
            dt_local = dt_utc.astimezone(ZoneInfo(tz_name))
            local_display = dt_local.strftime("%d %b %Y, %I:%M %p")
        except Exception:
            local_display = dt_utc.strftime("%Y-%m-%d %H:%M UTC") if dt_utc else ""

        sch_dict = {
            "id": v.schedule.id,
            "scheduled_publish_at": dt_utc.isoformat() if dt_utc else "",
            "local_display": local_display,
            "slot_time_label": v.schedule.slot_time_label,
            "timezone": tz_name,
            "privacy_status": v.schedule.privacy_status,
            "use_youtube_native_schedule": v.schedule.use_youtube_native_schedule,
            "status": v.schedule.status,
        }

    return {
        "id": v.id,
        "title": v.title,
        "original_filename": v.original_filename,
        "source_type": v.source_type,
        "drive_file_id": v.drive_file_id,
        "drive_folder_id": v.drive_folder_id,
        "drive_folder_name": v.drive_folder_name,
        "file_path": v.file_path,
        "video_stream_url": f"/api/v1/media/video/{v.id}" if v.file_path else "",
        "file_size_bytes": v.file_size_bytes,
        "duration_seconds": v.duration_seconds,
        "resolution": v.resolution,
        "status": v.status,
        "download_progress": v.download_progress,
        "upload_progress": v.upload_progress,
        "youtube_video_id": v.youtube_video_id,
        "youtube_url": v.youtube_url,
        "error_message": v.error_message,
        "created_at": v.created_at.isoformat() if v.created_at else "",
        "seo": seo_dict,
        "thumbnail": thumb_dict,
        "schedule": sch_dict,
    }


@router.get("/dashboard")
def get_dashboard_summary(db: Session = Depends(get_db)):
    cfg = get_or_create_automation_settings(db)
    drive_accounts = (
        db.query(GoogleAccount)
        .filter(GoogleAccount.account_purpose == "drive", GoogleAccount.is_active == True)
        .order_by(GoogleAccount.id.desc())
        .all()
    )
    yt_accounts = (
        db.query(GoogleAccount)
        .filter(
            GoogleAccount.account_purpose == "youtube", GoogleAccount.is_active == True
        )
        .order_by(GoogleAccount.id.desc())
        .all()
    )
    yt_channel = (
        db.query(YouTubeChannel)
        .filter(YouTubeChannel.is_connected == True)
        .order_by(YouTubeChannel.id.desc())
        .first()
    )
    drive_folders = db.query(DriveFolder).order_by(DriveFolder.id.desc()).all()
    videos = db.query(Video).order_by(Video.id.desc()).all()
    logs = (
        db.query(ActivityLog)
        .order_by(ActivityLog.id.desc())
        .limit(30)
        .all()
    )

    counts = {
        "total": len(videos),
        "pending": sum(1 for v in videos if v.status in ("pending", "ready_for_review")),
        "processing": sum(
            1 for v in videos if v.status in ("downloading", "analyzing", "uploading")
        ),
        "scheduled": sum(1 for v in videos if v.status == "scheduled"),
        "uploaded": sum(1 for v in videos if v.status == "uploaded"),
        "failed": sum(1 for v in videos if v.status == "failed"),
    }

    return {
        "counts": counts,
        "drive_accounts": [
            {
                "id": a.id,
                "email": a.email,
                "display_name": a.display_name,
                "avatar_url": a.avatar_url,
                "has_live_oauth": bool(a.refresh_token_enc),
                "connected_at": a.connected_at.isoformat() if a.connected_at else "",
            }
            for a in drive_accounts
        ],
        "youtube_accounts": [
            {
                "id": a.id,
                "email": a.email,
                "display_name": a.display_name,
                "avatar_url": a.avatar_url,
                "has_live_oauth": bool(a.refresh_token_enc),
            }
            for a in yt_accounts
        ],
        "youtube_channel": {
            "id": yt_channel.id,
            "channel_id": yt_channel.channel_id,
            "title": yt_channel.title,
            "custom_url": yt_channel.custom_url,
            "avatar_url": yt_channel.avatar_url,
            "subscriber_count": yt_channel.subscriber_count,
            "video_count": yt_channel.video_count,
            "view_count": yt_channel.view_count,
            "default_privacy": yt_channel.default_privacy,
        }
        if yt_channel
        else None,
        "drive_folders": [
            {
                "id": f.id,
                "folder_id": f.folder_id,
                "folder_name": f.folder_name,
                "account_email": f.account_email,
                "auto_scan": f.auto_scan,
                "auto_download": f.auto_download,
                "auto_schedule": f.auto_schedule,
                "videos_found": f.videos_found,
                "last_scanned_at": f.last_scanned_at.isoformat()
                if f.last_scanned_at
                else None,
            }
            for f in drive_folders
        ],
        "automation": {
            "engine_state": cfg.engine_state,
            "preset_mode": cfg.preset_mode,
            "drive_scan_mode": cfg.drive_scan_mode,
            "download_mode": cfg.download_mode,
            "seo_mode": cfg.seo_mode,
            "thumbnail_mode": cfg.thumbnail_mode,
            "upload_mode": cfg.upload_mode,
            "schedule_mode": cfg.schedule_mode,
            "daily_upload_limit": cfg.daily_upload_limit,
            "default_timezone": cfg.default_timezone,
            "daily_time_slots": json.loads(
                cfg.daily_time_slots_json or '["10:00", "14:00", "18:00", "21:00"]'
            ),
            "scan_interval_minutes": cfg.scan_interval_minutes,
            "default_privacy": cfg.default_privacy,
            "default_category_id": cfg.default_category_id,
            "default_seo_language": cfg.default_seo_language,
            "use_youtube_native_schedule": cfg.use_youtube_native_schedule,
        },
        "recent_videos": [serialize_video(v) for v in videos[:15]],
        "activity_logs": [
            {
                "id": l.id,
                "level": l.level,
                "category": l.category,
                "message": l.message,
                "video_id": l.video_id,
                "created_at": l.created_at.isoformat() if l.created_at else "",
            }
            for l in logs
        ],
    }


# ========================================================
# IN-APP CREDENTIALS & GOOGLE OAUTH (CONNECT ANY DRIVE / YOUTUBE)
# ========================================================

@router.get("/credentials")
def get_credentials_status(db: Session = Depends(get_db)):
    cred = db.query(AppCredential).first()
    client_id = (
        cred.google_client_id if (cred and cred.google_client_id) else settings.GOOGLE_CLIENT_ID
    )
    client_secret = (
        decrypt_secret(cred.google_client_secret_enc)
        if (cred and cred.google_client_secret_enc)
        else settings.GOOGLE_CLIENT_SECRET
    )
    gemini_key = (
        decrypt_secret(cred.gemini_api_key_enc)
        if (cred and cred.gemini_api_key_enc)
        else settings.GEMINI_API_KEY
    )
    redirect_uri = (
        cred.google_redirect_uri
        if (cred and cred.google_redirect_uri)
        else settings.GOOGLE_REDIRECT_URI
    )
    gemini_model = (
        cred.gemini_model if (cred and cred.gemini_model) else settings.GEMINI_MODEL
    )

    return {
        "google_oauth_configured": bool(client_id and client_secret),
        "google_client_id": client_id,
        "google_client_secret_masked": mask_secret(client_secret),
        "google_redirect_uri": redirect_uri,
        "gemini_configured": bool(gemini_key),
        "gemini_api_key_masked": mask_secret(gemini_key),
        "gemini_model": gemini_model,
    }


@router.post("/credentials")
def update_credentials(
    req: CredentialUpdateRequest, db: Session = Depends(get_db)
):
    cred = db.query(AppCredential).first()
    if not cred:
        cred = AppCredential()
        db.add(cred)

    if req.google_client_id is not None:
        cred.google_client_id = req.google_client_id.strip()
    if req.google_client_secret is not None and req.google_client_secret.strip():
        cred.google_client_secret_enc = encrypt_secret(req.google_client_secret.strip())
    if req.google_redirect_uri is not None and req.google_redirect_uri.strip():
        cred.google_redirect_uri = req.google_redirect_uri.strip()
    if req.gemini_api_key is not None and req.gemini_api_key.strip():
        cred.gemini_api_key_enc = encrypt_secret(req.gemini_api_key.strip())
    if req.gemini_model is not None and req.gemini_model.strip():
        cred.gemini_model = req.gemini_model.strip()

    db.commit()
    log_event(
        db,
        "SYSTEM",
        "Updated Google OAuth / Gemini API credentials in App Vault (Encrypted with Fernet).",
        "SUCCESS",
    )
    return get_credentials_status(db)


@router.post("/credentials/upload-client-secret")
async def upload_google_client_secret_json(
    file: UploadFile = File(...), db: Session = Depends(get_db)
):
    """
    Allows the user to directly upload the `client_secret.json` file downloaded from
    Google Cloud Console so they never even have to copy-paste Client ID or Client Secret!
    """
    raw = await file.read()
    try:
        parsed = json.loads(raw.decode("utf-8"))
        block = parsed.get("installed") or parsed.get("web") or parsed
        client_id = block.get("client_id", "")
        client_secret = block.get("client_secret", "")
        if not client_id or not client_secret:
            raise ValueError("Missing client_id or client_secret in JSON file.")
    except Exception as exc:
        raise HTTPException(
            status_code=400, detail=f"Invalid Google client_secret.json file: {exc}"
        )

    cred = db.query(AppCredential).first()
    if not cred:
        cred = AppCredential()
        db.add(cred)
    cred.google_client_id = client_id
    cred.google_client_secret_enc = encrypt_secret(client_secret)
    db.commit()
    log_event(
        db,
        "SYSTEM",
        "Uploaded & encrypted Google Cloud client_secret.json successfully!",
        "SUCCESS",
    )
    return get_credentials_status(db)


@router.get("/oauth/url")
def get_oauth_url(
    purpose: str = Query("drive", description="drive or youtube"),
    db: Session = Depends(get_db),
):
    return build_google_oauth_url(db, purpose=purpose)


@router.get("/oauth/callback", response_class=HTMLResponse)
def oauth_callback(
    code: str = Query(...),
    state: str = Query("drive"),
    db: Session = Depends(get_db),
):
    try:
        acc = handle_oauth_callback(db, code=code, state_purpose=state)
        return f"""
        <html>
          <body style="background:#0B0F19;color:#F8FAFC;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
            <div style="background:#111827;padding:32px;border-radius:16px;border:1px solid #10B981;text-align:center;max-width:440px;">
              <h2 style="color:#10B981;margin-top:0;">✅ Connected Successfully!</h2>
              <p>Connected <b>{acc.email}</b> for <b>{state.upper()}</b>.</p>
              <p style="color:#94A3B8;font-size:14px;">You can close this tab and return to YT AutoPilot Pro.</p>
              <script>setTimeout(() => window.close(), 2000);</script>
            </div>
          </body>
        </html>
        """
    except Exception as exc:
        return f"""
        <html>
          <body style="background:#0B0F19;color:#F8FAFC;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;">
            <div style="background:#111827;padding:32px;border-radius:16px;border:1px solid #EF4444;text-align:center;max-width:480px;">
              <h2 style="color:#EF4444;margin-top:0;">OAuth Connection Error</h2>
              <p>{exc}</p>
            </div>
          </body>
        </html>
        """


@router.post("/accounts/connect-quick")
def connect_account_quick(
    purpose: str = Form("drive"),
    email: str = Form("my.drive.videos@gmail.com"),
    display_name: str = Form("My Google Account"),
    channel_title: str = Form("My YouTube Automation Channel"),
    db: Session = Depends(get_db),
):
    """
    Allows connecting/switching any Google Drive account or YouTube channel profile
    instantly for testing or local folder/URL mapping, while also supporting full OAuth 2.0.
    """
    acc = (
        db.query(GoogleAccount)
        .filter(
            GoogleAccount.account_purpose == purpose,
            GoogleAccount.email == email,
        )
        .first()
    )
    if not acc:
        acc = GoogleAccount(account_purpose=purpose, email=email)
        db.add(acc)
    acc.display_name = display_name or email.split("@")[0]
    acc.is_active = True
    db.commit()
    db.refresh(acc)

    if purpose == "youtube":
        ch = db.query(YouTubeChannel).first()
        if not ch:
            ch = YouTubeChannel(
                channel_id=f"UC_{email.split('@')[0].upper()}_PRO",
                title=channel_title,
            )
            db.add(ch)
        ch.google_account_id = acc.id
        ch.title = channel_title or f"{acc.display_name} Channel"
        ch.custom_url = f"@{ch.title.lower().replace(' ', '')}"
        ch.subscriber_count = max(ch.subscriber_count or 0, 1250)
        ch.video_count = db.query(Video).filter(Video.status == "uploaded").count()
        ch.is_connected = True
        db.commit()

    log_event(
        db,
        purpose.upper(),
        f"Connected {purpose.title()} account '{email}' inside app.",
        "SUCCESS",
    )
    return {"success": True, "account_id": acc.id, "email": acc.email}


@router.delete("/accounts/{account_id}")
def disconnect_google_account(account_id: int, db: Session = Depends(get_db)):
    acc = db.query(GoogleAccount).filter(GoogleAccount.id == account_id).first()
    if not acc:
        raise HTTPException(status_code=404, detail="Account not found")
    purpose = acc.account_purpose
    email = acc.email
    if purpose == "youtube":
        db.query(YouTubeChannel).filter(
            YouTubeChannel.google_account_id == acc.id
        ).delete()
    db.delete(acc)
    db.commit()
    log_event(
        db,
        purpose.upper(),
        f"Disconnected {purpose.title()} account '{email}'. Ready to connect any new account.",
        "INFO",
    )
    return {"success": True}


# ========================================================
# GOOGLE DRIVE BROWSING, FOLDER SELECTION & AUTO-DOWNLOAD
# ========================================================

@router.get("/drive/browse")
def browse_drive(
    account_id: Optional[int] = None, db: Session = Depends(get_db)
):
    folders = browse_google_drive_folders(db, account_id=account_id)
    return {"folders": folders}


@router.post("/drive/folders")
def add_drive_folder_to_watch(
    req: DriveFolderCreateRequest, db: Session = Depends(get_db)
):
    existing = (
        db.query(DriveFolder)
        .filter(DriveFolder.folder_id == req.folder_id)
        .first()
    )
    if existing:
        existing.folder_name = req.folder_name
        existing.auto_scan = req.auto_scan
        existing.auto_download = req.auto_download
        existing.auto_schedule = req.auto_schedule
        db.commit()
        db.refresh(existing)
        folder = existing
    else:
        folder = DriveFolder(
            folder_id=req.folder_id,
            folder_name=req.folder_name,
            account_email=req.account_email or "",
            auto_scan=req.auto_scan,
            auto_download=req.auto_download,
            auto_schedule=req.auto_schedule,
        )
        db.add(folder)
        db.commit()
        db.refresh(folder)

    log_event(
        db,
        "DRIVE",
        f"Added Google Drive source folder '{folder.folder_name}' ({folder.folder_id}) for auto-download & scheduling.",
        "SUCCESS",
    )
    return {"success": True, "folder_id": folder.folder_id}


@router.delete("/drive/folders/{db_folder_id}")
def remove_drive_folder(db_folder_id: int, db: Session = Depends(get_db)):
    folder = db.query(DriveFolder).filter(DriveFolder.id == db_folder_id).first()
    if not folder:
        raise HTTPException(status_code=404, detail="Folder not found")
    name = folder.folder_name
    db.delete(folder)
    db.commit()
    log_event(db, "DRIVE", f"Removed Drive folder '{name}' from watch list.", "INFO")
    return {"success": True}


@router.post("/drive/scan")
def scan_drive_folders_now(
    folder_id: Optional[int] = None,
    auto_schedule_after_download: bool = Query(True),
    db: Session = Depends(get_db),
):
    """
    Scans selected Google Drive folder(s), downloads new videos automatically,
    generates AI SEO + Thumbnail, and optionally schedules them into the user's daily time slots!
    """
    query = db.query(DriveFolder)
    if folder_id:
        query = query.filter(DriveFolder.id == folder_id)
    folders = query.all()

    if not folders:
        # Automatically create a default watched Drive folder if none exists yet
        default_folder = DriveFolder(
            folder_id="drive_folder_daily_shorts",
            folder_name="YouTube Daily Videos (Auto-Upload)",
            account_email="my.drive@gmail.com",
            auto_scan=True,
            auto_download=True,
            auto_schedule=True,
        )
        db.add(default_folder)
        db.commit()
        db.refresh(default_folder)
        folders = [default_folder]

    all_new_videos = []
    for f in folders:
        new_vids = scan_and_download_drive_folder(db, f, auto_download=True)
        all_new_videos.extend(new_vids)

    cfg = get_or_create_automation_settings(db)
    for v in all_new_videos:
        ensure_video_has_seo_and_thumbnail(
            db,
            v,
            language=cfg.default_seo_language,
            category_id=cfg.default_category_id,
        )

    scheduled_count = 0
    if auto_schedule_after_download and all_new_videos:
        schedules = auto_schedule_videos_into_time_slots(
            db=db,
            video_ids=[v.id for v in all_new_videos],
        )
        scheduled_count = len(schedules)

    return {
        "success": True,
        "downloaded_count": len(all_new_videos),
        "scheduled_count": scheduled_count,
        "videos": [serialize_video(v) for v in all_new_videos],
    }


# ========================================================
# VIDEO MANAGER, AI SEO STUDIO & THUMBNAIL STUDIO
# ========================================================

@router.get("/videos")
def list_videos(
    status: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
):
    q = db.query(Video)
    if status and status != "all":
        q = q.filter(Video.status == status)
    videos = q.order_by(Video.id.desc()).all()
    if search:
        s = search.lower()
        videos = [
            v
            for v in videos
            if s in v.title.lower() or s in v.original_filename.lower()
        ]
    return {"videos": [serialize_video(v) for v in videos]}


@router.post("/videos/upload-local")
async def import_local_video(
    file: UploadFile = File(...),
    auto_seo_and_schedule: bool = Form(True),
    db: Session = Depends(get_db),
):
    safe_name = f"local_{int(datetime.now(timezone.utc).timestamp())}_{Path(file.filename or 'video.mp4').name}"
    dest_path = VIDEOS_DIR / safe_name
    with open(dest_path, "wb") as out:
        shutil.copyfileobj(file.file, out)

    meta = inspect_video_file(dest_path)
    # Check duplicate hash
    if meta["file_hash"]:
        dup = db.query(Video).filter(Video.file_hash == meta["file_hash"]).first()
        if dup:
            raise HTTPException(
                status_code=409,
                detail=f"Duplicate video detected! Matches existing video '{dup.title}'.",
            )

    clean_title = (
        Path(file.filename or "New Video")
        .stem.replace("_", " ")
        .replace("-", " ")
        .strip()
    )
    video = Video(
        title=clean_title,
        original_filename=file.filename or safe_name,
        source_type="local",
        file_path=str(dest_path),
        file_hash=meta["file_hash"],
        file_size_bytes=meta["file_size_bytes"],
        duration_seconds=meta["duration_seconds"],
        resolution=meta["resolution"],
        status="ready_for_review",
        download_progress=100,
    )
    db.add(video)
    db.commit()
    db.refresh(video)

    cfg = get_or_create_automation_settings(db)
    ensure_video_has_seo_and_thumbnail(
        db,
        video,
        language=cfg.default_seo_language,
        category_id=cfg.default_category_id,
    )

    if auto_seo_and_schedule:
        auto_schedule_videos_into_time_slots(db, video_ids=[video.id])
        db.refresh(video)

    log_event(
        db,
        "VIDEO",
        f"Imported local video '{video.title}' ({video.resolution}).",
        "SUCCESS",
        video.id,
    )
    return {"success": True, "video": serialize_video(video)}


@router.post("/videos/{video_id}/seo")
def generate_video_seo_endpoint(
    video_id: int, req: SEOGenerateRequest, db: Session = Depends(get_db)
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    seo_data = generate_seo_for_video(
        db,
        video,
        language=req.language,
        custom_prompt=req.custom_prompt,
        category_id=req.category_id,
    )
    seo = video.seo
    if not seo:
        seo = SEOMetadata(video_id=video.id)
        db.add(seo)

    seo.seo_title = seo_data["seo_title"]
    seo.alternative_titles_json = json.dumps(seo_data.get("alternative_titles", []))
    seo.description = seo_data["description"]
    seo.tags_json = json.dumps(seo_data.get("tags", []))
    seo.keywords_json = json.dumps(seo_data.get("keywords", []))
    seo.hashtags_json = json.dumps(seo_data.get("hashtags", []))
    seo.category_id = seo_data.get("category_id", req.category_id)
    seo.language = req.language
    seo.ai_model_used = seo_data.get("ai_model_used", "gemini-2.5-flash")
    seo.is_approved = True
    video.title = seo_data["seo_title"]
    db.commit()
    db.refresh(video)

    log_event(
        db,
        "SEO",
        f"Generated AI SEO metadata ({req.language}) for '{video.title}'.",
        "SUCCESS",
        video.id,
    )
    return {"success": True, "video": serialize_video(video)}


@router.put("/videos/{video_id}/seo")
def save_video_seo_endpoint(
    video_id: int, req: SEOMetadataUpdateRequest, db: Session = Depends(get_db)
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    seo = video.seo
    if not seo:
        seo = SEOMetadata(video_id=video.id)
        db.add(seo)

    seo.seo_title = req.seo_title
    seo.description = req.description
    seo.tags_json = json.dumps(req.tags)
    seo.keywords_json = json.dumps(req.keywords)
    seo.hashtags_json = json.dumps(req.hashtags)
    seo.category_id = req.category_id
    seo.playlist_id = req.playlist_id
    seo.playlist_name = req.playlist_name
    seo.language = req.language
    seo.is_approved = req.is_approved
    video.title = req.seo_title
    db.commit()
    db.refresh(video)

    log_event(
        db,
        "SEO",
        f"Saved & approved SEO metadata for '{video.title}'.",
        "SUCCESS",
        video.id,
    )
    return {"success": True, "video": serialize_video(video)}


@router.post("/videos/{video_id}/thumbnail")
def generate_video_thumbnail_endpoint(
    video_id: int, req: ThumbnailGenerateRequest, db: Session = Depends(get_db)
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    headline = req.headline_text or video.title[:30]
    thumb_path = generate_youtube_thumbnail(
        video_id=video.id,
        video_path=video.file_path,
        headline_text=headline,
        subheadline_text=req.subheadline_text,
        badge_text=req.badge_text,
        accent_color=req.accent_color,
        template_style=req.template_style,
        frame_timestamp_sec=req.frame_timestamp_sec,
    )

    thumb = video.thumbnail
    if not thumb:
        thumb = Thumbnail(video_id=video.id)
        db.add(thumb)

    thumb.file_path = str(thumb_path)
    thumb.headline_text = headline
    thumb.subheadline_text = req.subheadline_text
    thumb.badge_text = req.badge_text
    thumb.accent_color = req.accent_color
    thumb.template_style = req.template_style
    thumb.frame_timestamp_sec = req.frame_timestamp_sec
    thumb.updated_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(video)

    log_event(
        db,
        "THUMBNAIL",
        f"Generated 1280x720 HD YouTube thumbnail for '{video.title}'.",
        "SUCCESS",
        video.id,
    )
    return {"success": True, "video": serialize_video(video)}


@router.delete("/videos/{video_id}")
def delete_video_endpoint(video_id: int, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    title = video.title
    db.delete(video)
    db.commit()
    log_event(db, "VIDEO", f"Deleted video '{title}'.", "INFO")
    return {"success": True}


# ========================================================
# YOUTUBE SCHEDULER & DAILY TIME SLOTS (KIS-KIS TIME POST KARNA HAI)
# ========================================================

@router.get("/schedules")
def list_schedules(db: Session = Depends(get_db)):
    cfg = get_or_create_automation_settings(db)
    schedules = (
        db.query(Schedule)
        .order_by(Schedule.scheduled_publish_at.asc())
        .all()
    )
    items = []
    for s in schedules:
        if s.video:
            items.append(serialize_video(s.video))
    return {
        "schedules": items,
        "daily_time_slots": json.loads(
            cfg.daily_time_slots_json or '["10:00", "14:00", "18:00", "21:00"]'
        ),
        "default_timezone": cfg.default_timezone,
        "daily_upload_limit": cfg.daily_upload_limit,
    }


@router.post("/schedules/single")
def schedule_single_video_endpoint(
    req: ScheduleCreateRequest, db: Session = Depends(get_db)
):
    video = db.query(Video).filter(Video.id == req.video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    try:
        tz = ZoneInfo(req.timezone)
    except Exception:
        tz = ZoneInfo("UTC")

    dt_raw = datetime.fromisoformat(req.scheduled_publish_at.replace("Z", "+00:00"))
    if dt_raw.tzinfo is None:
        dt_local = dt_raw.replace(tzinfo=tz)
    else:
        dt_local = dt_raw.astimezone(tz)
    dt_utc = dt_local.astimezone(timezone.utc)

    schedule_single_video(
        db=db,
        video=video,
        scheduled_utc=dt_utc,
        timezone_str=req.timezone,
        slot_label=dt_local.strftime("%H:%M"),
        privacy_status=req.privacy_status,
        use_youtube_native_schedule=req.use_youtube_native_schedule,
    )
    db.refresh(video)
    return {"success": True, "video": serialize_video(video)}


from app.services.drive_package_parser import extract_drive_folder_id


@router.post("/schedules/from-drive-link")
def schedule_directly_from_drive_link(
    drive_link: str = Form(...),
    folder_name: str = Form("Drive Package"),
    scheduled_publish_at: str = Form(""),
    timezone_str: str = Form("Asia/Karachi"),
    privacy_status: str = Form("public"),
    db: Session = Depends(get_db),
):
    """
    User pastes ANY Google Drive folder link containing:
      - Video (.mp4/.mov/.mkv)
      - Thumbnail (.png/.jpg)
      - Title, Description & Tags (.txt/.json/Google Doc)
    This endpoint downloads the complete package and schedules it on YouTube!
    """
    folder_id = extract_drive_folder_id(drive_link)
    if not folder_id:
        raise HTTPException(status_code=400, detail="Invalid Google Drive link or folder ID")

    folder = db.query(DriveFolder).filter(DriveFolder.folder_id == folder_id).first()
    if not folder:
        folder = DriveFolder(
            folder_id=folder_id,
            folder_name=folder_name or f"Drive_{folder_id[:8]}",
            auto_scan=True,
            auto_download=True,
            auto_schedule=True,
        )
        db.add(folder)
        db.commit()
        db.refresh(folder)

    new_videos = scan_and_download_drive_folder(db, folder, auto_download=True)
    cfg = get_or_create_automation_settings(db)
    for v in new_videos:
        ensure_video_has_seo_and_thumbnail(
            db,
            v,
            language=cfg.default_seo_language,
            category_id=cfg.default_category_id,
        )

    target_videos = new_videos or (
        db.query(Video)
        .filter(
            Video.drive_folder_id == folder_id,
            Video.status.in_(["pending", "ready_for_review"]),
        )
        .all()
    )

    scheduled_count = 0
    if target_videos:
        if scheduled_publish_at.strip():
            try:
                tz = ZoneInfo(timezone_str)
            except Exception:
                tz = ZoneInfo("UTC")
            dt_raw = datetime.fromisoformat(scheduled_publish_at.replace("Z", "+00:00"))
            dt_local = dt_raw.replace(tzinfo=tz) if dt_raw.tzinfo is None else dt_raw.astimezone(tz)
            dt_utc = dt_local.astimezone(timezone.utc)
            for v in target_videos:
                schedule_single_video(
                    db=db,
                    video=v,
                    scheduled_utc=dt_utc,
                    timezone_str=timezone_str,
                    slot_label=dt_local.strftime("%H:%M"),
                    privacy_status=privacy_status,
                    use_youtube_native_schedule=True,
                )
                scheduled_count += 1
        else:
            schedules = auto_schedule_videos_into_time_slots(
                db=db,
                video_ids=[v.id for v in target_videos],
                timezone_str=timezone_str,
                privacy_status=privacy_status,
                use_youtube_native_schedule=True,
            )
            scheduled_count = len(schedules)

    return {
        "success": True,
        "folder_id": folder_id,
        "downloaded_count": len(new_videos),
        "scheduled_count": scheduled_count,
        "videos": [serialize_video(v) for v in target_videos],
    }


@router.post("/schedules/auto-slots")
def auto_schedule_time_slots_endpoint(
    req: AutoSlotScheduleRequest, db: Session = Depends(get_db)
):
    """
    Saves the user's chosen daily posting times (e.g. ["10:00", "14:00", "18:00", "21:00"])
    and automatically schedules all pending/selected videos into those time slots on YouTube!
    """
    cfg = get_or_create_automation_settings(db)
    if req.time_slots:
        cfg.daily_time_slots_json = json.dumps(req.time_slots)
    if req.timezone:
        cfg.default_timezone = req.timezone
    db.commit()

    schedules = auto_schedule_videos_into_time_slots(
        db=db,
        video_ids=req.video_ids,
        time_slots=req.time_slots,
        timezone_str=req.timezone,
        start_date_str=req.start_date,
        privacy_status=req.privacy_status,
        use_youtube_native_schedule=req.use_youtube_native_schedule,
    )
    return {
        "success": True,
        "scheduled_count": len(schedules),
        "daily_time_slots": req.time_slots,
    }


@router.post("/videos/{video_id}/upload-now")
def upload_video_immediately_endpoint(
    video_id: int,
    privacy_status: str = Query("public"),
    db: Session = Depends(get_db),
):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")

    cfg = get_or_create_automation_settings(db)
    ensure_video_has_seo_and_thumbnail(
        db,
        video,
        language=cfg.default_seo_language,
        category_id=cfg.default_category_id,
    )
    res = upload_or_schedule_video_to_youtube(
        db, video, publish_at_iso_utc=None, privacy_status=privacy_status
    )
    db.refresh(video)
    return {"success": True, "result": res, "video": serialize_video(video)}


# ========================================================
# AUTOMATION ENGINE & 1-CLICK AUTOPILOT PIPELINE
# ========================================================

@router.put("/automation")
def update_automation_settings_endpoint(
    req: AutomationSettingsUpdateRequest, db: Session = Depends(get_db)
):
    cfg = get_or_create_automation_settings(db)

    if req.preset_mode:
        cfg.preset_mode = req.preset_mode
        if req.preset_mode == "Full Auto":
            cfg.drive_scan_mode = "AUTO"
            cfg.download_mode = "AUTO"
            cfg.seo_mode = "AUTO"
            cfg.thumbnail_mode = "AUTO"
            cfg.upload_mode = "AUTO"
            cfg.schedule_mode = "AUTO"
        elif req.preset_mode == "SEO Auto":
            cfg.drive_scan_mode = "AUTO"
            cfg.download_mode = "AUTO"
            cfg.seo_mode = "AUTO"
            cfg.thumbnail_mode = "AUTO"
            cfg.upload_mode = "MANUAL"
            cfg.schedule_mode = "MANUAL"
        elif req.preset_mode == "Upload Auto":
            cfg.drive_scan_mode = "AUTO"
            cfg.download_mode = "AUTO"
            cfg.seo_mode = "MANUAL"
            cfg.thumbnail_mode = "MANUAL"
            cfg.upload_mode = "AUTO"
            cfg.schedule_mode = "AUTO"
        elif req.preset_mode == "Manual":
            cfg.drive_scan_mode = "MANUAL"
            cfg.download_mode = "MANUAL"
            cfg.seo_mode = "MANUAL"
            cfg.thumbnail_mode = "MANUAL"
            cfg.upload_mode = "MANUAL"
            cfg.schedule_mode = "MANUAL"

    for field in (
        "engine_state",
        "drive_scan_mode",
        "download_mode",
        "seo_mode",
        "thumbnail_mode",
        "upload_mode",
        "schedule_mode",
        "daily_upload_limit",
        "default_timezone",
        "scan_interval_minutes",
        "default_privacy",
        "default_category_id",
        "default_seo_language",
        "use_youtube_native_schedule",
    ):
        val = getattr(req, field, None)
        if val is not None:
            setattr(cfg, field, val)

    if req.daily_time_slots is not None:
        cfg.daily_time_slots_json = json.dumps(req.daily_time_slots)

    db.commit()
    db.refresh(cfg)
    log_event(
        db,
        "AUTOMATION",
        f"Updated Automation Engine ({cfg.preset_mode} | State: {cfg.engine_state} | Daily Slots: {cfg.daily_time_slots_json})",
        "INFO",
    )
    return get_dashboard_summary(db)["automation"]


@router.post("/automation/run-now")
def trigger_full_autopilot_now(db: Session = Depends(get_db)):
    """
    Runs the complete Drive -> Auto-Download -> AI SEO & Thumbnail -> Daily Time-Slot YouTube Schedule pipeline.
    """
    summary = run_full_drive_to_youtube_autopilot(db)
    return {"success": True, "summary": summary}


# ========================================================
# MEDIA STREAMING (THUMBNAIL & VIDEO PREVIEW)
# ========================================================

@router.get("/media/thumbnail/{video_id}")
def serve_video_thumbnail(video_id: int, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video or not video.thumbnail or not video.thumbnail.file_path:
        raise HTTPException(status_code=404, detail="Thumbnail not found")
    path = Path(video.thumbnail.file_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Thumbnail file missing on disk")
    return FileResponse(path, media_type="image/png")


@router.get("/media/video/{video_id}")
def serve_video_stream(video_id: int, db: Session = Depends(get_db)):
    video = db.query(Video).filter(Video.id == video_id).first()
    if not video or not video.file_path:
        raise HTTPException(status_code=404, detail="Video not found")
    path = Path(video.file_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail="Video file missing on disk")
    return FileResponse(path, media_type="video/mp4")


@router.get("/download-project-zip")
def download_project_zip():
    from app.core.config import DATA_DIR
    zip_path = DATA_DIR / "yt-autopilot-pro-source.zip"
    if not zip_path.exists():
        raise HTTPException(status_code=404, detail="Project ZIP not found")
    return FileResponse(
        zip_path,
        media_type="application/zip",
        filename="yt-autopilot-pro-full.zip",
    )


@router.get("/download-windows-exe")
def download_windows_exe():
    from app.core.config import DATA_DIR
    zip_path = DATA_DIR / "YT-AutoPilot-Pro-Windows-x64.zip"
    if not zip_path.exists():
        raise HTTPException(status_code=404, detail="Windows EXE bundle not found")
    return FileResponse(
        zip_path,
        media_type="application/zip",
        filename="YT-AutoPilot-Pro-Windows-x64.zip",
    )


