from datetime import datetime, timezone
from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    Boolean,
    DateTime,
    ForeignKey,
    BigInteger,
)
from sqlalchemy.orm import relationship
from app.core.database import Base


def utc_now():
    return datetime.now(timezone.utc)


class AppCredential(Base):
    """
    Stores encrypted Google OAuth Client ID/Secret and Gemini API Key configured
    directly inside the desktop app's Settings screen so the user can connect
    ANY Google Drive or YouTube account inside the app without editing code.
    """
    __tablename__ = "app_credentials"

    id = Column(Integer, primary_key=True, index=True)
    google_client_id = Column(String(512), default="")
    google_client_secret_enc = Column(Text, default="")
    google_redirect_uri = Column(
        String(512), default="http://127.0.0.1:8765/api/v1/oauth/callback"
    )
    gemini_api_key_enc = Column(Text, default="")
    gemini_model = Column(String(128), default="gemini-2.5-flash")
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)


class GoogleAccount(Base):
    """
    Supports connecting ANY Google Drive account(s) and ANY YouTube account(s)
    independently inside the app.
    """
    __tablename__ = "google_accounts"

    id = Column(Integer, primary_key=True, index=True)
    account_purpose = Column(String(32), index=True)  # "drive" or "youtube"
    google_user_id = Column(String(255), index=True)
    email = Column(String(255), nullable=False)
    display_name = Column(String(255), nullable=False)
    avatar_url = Column(String(1024), default="")
    access_token_enc = Column(Text, default="")
    refresh_token_enc = Column(Text, default="")
    token_expiry = Column(DateTime, nullable=True)
    scopes = Column(Text, default="")
    is_active = Column(Boolean, default=True)
    connected_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)


class YouTubeChannel(Base):
    __tablename__ = "youtube_channels"

    id = Column(Integer, primary_key=True, index=True)
    google_account_id = Column(Integer, ForeignKey("google_accounts.id"), nullable=True)
    channel_id = Column(String(128), unique=True, index=True, nullable=False)
    title = Column(String(255), nullable=False)
    custom_url = Column(String(255), default="")
    avatar_url = Column(String(1024), default="")
    subscriber_count = Column(BigInteger, default=0)
    video_count = Column(BigInteger, default=0)
    view_count = Column(BigInteger, default=0)
    default_privacy = Column(String(32), default="public")  # private, unlisted, public
    default_category_id = Column(String(32), default="22")  # 22 = People & Blogs
    default_language = Column(String(32), default="Hinglish")
    is_connected = Column(Boolean, default=True)
    connected_at = Column(DateTime, default=utc_now)


class DriveFolder(Base):
    """
    Represents a selected Google Drive folder that the automation engine scans
    for new videos to auto-download and schedule on YouTube.
    """
    __tablename__ = "drive_folders"

    id = Column(Integer, primary_key=True, index=True)
    google_account_id = Column(Integer, ForeignKey("google_accounts.id"), nullable=True)
    folder_id = Column(String(255), unique=True, index=True, nullable=False)
    folder_name = Column(String(255), nullable=False)
    account_email = Column(String(255), default="")
    auto_scan = Column(Boolean, default=True)
    auto_download = Column(Boolean, default=True)
    auto_schedule = Column(Boolean, default=True)
    videos_found = Column(Integer, default=0)
    last_scanned_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=utc_now)


class Video(Base):
    """
    Master video table tracking videos imported from Google Drive or Local Disk.
    Prevents duplicate downloads/uploads via drive_file_id and file_hash.
    """
    __tablename__ = "videos"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(512), nullable=False)
    original_filename = Column(String(512), nullable=False)
    source_type = Column(String(32), default="drive")  # "drive" or "local"
    drive_file_id = Column(String(255), unique=True, nullable=True, index=True)
    drive_folder_id = Column(String(255), nullable=True)
    drive_folder_name = Column(String(255), default="")
    file_path = Column(String(1024), default="")
    file_hash = Column(String(128), nullable=True, index=True)
    file_size_bytes = Column(BigInteger, default=0)
    duration_seconds = Column(Integer, default=0)
    resolution = Column(String(64), default="1920x1080")
    status = Column(
        String(64), default="pending", index=True
    )  # pending, downloading, analyzing, ready_for_review, scheduled, uploading, uploaded, failed
    download_progress = Column(Integer, default=0)
    upload_progress = Column(Integer, default=0)
    youtube_video_id = Column(String(128), nullable=True)
    youtube_url = Column(String(512), default="")
    error_message = Column(Text, default="")
    transcript_or_notes = Column(Text, default="")
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    seo = relationship(
        "SEOMetadata", back_populates="video", uselist=False, cascade="all, delete-orphan"
    )
    thumbnail = relationship(
        "Thumbnail", back_populates="video", uselist=False, cascade="all, delete-orphan"
    )
    schedule = relationship(
        "Schedule", back_populates="video", uselist=False, cascade="all, delete-orphan"
    )


class SEOMetadata(Base):
    __tablename__ = "seo_metadata"

    id = Column(Integer, primary_key=True, index=True)
    video_id = Column(Integer, ForeignKey("videos.id", ondelete="CASCADE"), unique=True)
    seo_title = Column(String(255), default="")
    alternative_titles_json = Column(Text, default="[]")
    description = Column(Text, default="")
    tags_json = Column(Text, default="[]")
    keywords_json = Column(Text, default="[]")
    hashtags_json = Column(Text, default="[]")
    category_id = Column(String(32), default="22")
    playlist_id = Column(String(128), default="")
    playlist_name = Column(String(255), default="")
    language = Column(String(64), default="Hinglish")
    ai_model_used = Column(String(128), default="gemini-2.5-flash")
    is_approved = Column(Boolean, default=False)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    video = relationship("Video", back_populates="seo")


class Thumbnail(Base):
    __tablename__ = "thumbnails"

    id = Column(Integer, primary_key=True, index=True)
    video_id = Column(Integer, ForeignKey("videos.id", ondelete="CASCADE"), unique=True)
    file_path = Column(String(1024), default="")
    headline_text = Column(String(255), default="")
    subheadline_text = Column(String(255), default="")
    badge_text = Column(String(64), default="NEW VIDEO")
    accent_color = Column(String(32), default="#FF0033")
    template_style = Column(String(64), default="cyber_glow")
    frame_timestamp_sec = Column(Integer, default=2)
    is_custom_upload = Column(Boolean, default=False)
    uploaded_to_youtube = Column(Boolean, default=False)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    video = relationship("Video", back_populates="thumbnail")


class Schedule(Base):
    """
    Stores the exact scheduled date & time for publishing to YouTube.
    Supports both YouTube Native Scheduling (status.publishAt) and background worker triggers.
    """
    __tablename__ = "schedules"

    id = Column(Integer, primary_key=True, index=True)
    video_id = Column(Integer, ForeignKey("videos.id", ondelete="CASCADE"), unique=True)
    scheduled_publish_at = Column(DateTime, nullable=False, index=True)
    slot_time_label = Column(String(32), default="")  # e.g., "18:00"
    timezone = Column(String(64), default="Asia/Karachi")
    privacy_status = Column(String(32), default="public")  # final privacy after publishAt
    use_youtube_native_schedule = Column(Boolean, default=True)
    status = Column(
        String(32), default="scheduled", index=True
    )  # scheduled, uploading, published_scheduled_on_yt, completed, failed, cancelled
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)
    last_error = Column(Text, default="")
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    video = relationship("Video", back_populates="schedule")


class AutomationSettings(Base):
    """
    Global automation engine settings & daily posting time slots.
    For example: daily_time_slots_json = '["10:00", "14:00", "18:00", "21:00"]'
    """
    __tablename__ = "automation_settings"

    id = Column(Integer, primary_key=True, index=True)
    engine_state = Column(String(32), default="RUNNING")  # RUNNING, PAUSED, STOPPED
    preset_mode = Column(
        String(32), default="Full Auto"
    )  # Full Auto, SEO Auto, Upload Auto, Manual, Custom
    drive_scan_mode = Column(String(16), default="AUTO")  # AUTO or MANUAL
    download_mode = Column(String(16), default="AUTO")
    seo_mode = Column(String(16), default="AUTO")
    thumbnail_mode = Column(String(16), default="AUTO")
    upload_mode = Column(String(16), default="AUTO")
    schedule_mode = Column(String(16), default="AUTO")

    daily_upload_limit = Column(Integer, default=5)
    default_timezone = Column(String(64), default="Asia/Karachi")
    # JSON array of 24h time strings like ["10:00", "15:00", "20:00"]
    daily_time_slots_json = Column(Text, default='["10:00", "15:00", "20:00"]')
    scan_interval_minutes = Column(Integer, default=15)
    default_privacy = Column(String(32), default="public")
    default_category_id = Column(String(32), default="22")
    default_seo_language = Column(String(64), default="Hinglish")
    use_youtube_native_schedule = Column(Boolean, default=True)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)


class ActivityLog(Base):
    __tablename__ = "activity_logs"

    id = Column(Integer, primary_key=True, index=True)
    level = Column(String(16), default="INFO")  # INFO, SUCCESS, WARNING, ERROR
    category = Column(
        String(64), default="SYSTEM"
    )  # DRIVE, YOUTUBE, SEO, THUMBNAIL, SCHEDULER, AUTOMATION
    message = Column(Text, nullable=False)
    video_id = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=utc_now, index=True)
