from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from app.core.config import THUMBNAILS_DIR
from app.services.media_service import extract_video_frame


def _load_font(size: int, bold: bool = True):
    font_candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
        if bold
        else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    ]
    for path in font_candidates:
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, size=size)
            except Exception:
                pass
    return ImageFont.load_default()


def _hex_to_rgb(hex_color: str, fallback=(255, 0, 51)):
    h = (hex_color or "#FF0033").lstrip("#")
    if len(h) == 6:
        try:
            return tuple(int(h[i : i + 2], 16) for i in (0, 2, 4))
        except ValueError:
            return fallback
    return fallback


def generate_youtube_thumbnail(
    video_id: int,
    video_path: str,
    headline_text: str,
    subheadline_text: str = "",
    badge_text: str = "MUST WATCH",
    accent_color: str = "#FF0033",
    template_style: str = "cyber_glow",
    frame_timestamp_sec: int = 2,
) -> Path:
    """
    Creates a crisp 1280x720 HD YouTube thumbnail:
    1. Extracts a real video frame from video_path via FFmpeg (or creates a sleek studio backdrop).
    2. Applies a dramatic dark cinematic vignette on the left for high-contrast readability.
    3. Renders a vibrant badge, bold multi-line headline, subheadline, and glowing border.
    """
    out_path = THUMBNAILS_DIR / f"thumb_video_{video_id}.png"
    raw_frame = THUMBNAILS_DIR / f"raw_frame_{video_id}.jpg"

    base_img = None
    if video_path and Path(video_path).exists():
        if extract_video_frame(Path(video_path), raw_frame, frame_timestamp_sec):
            try:
                base_img = Image.open(raw_frame).convert("RGBA").resize((1280, 720))
            except Exception:
                base_img = None

    if base_img is None:
        base_img = Image.new("RGBA", (1280, 720), (13, 18, 30, 255))
        bg_draw = ImageDraw.Draw(base_img)
        accent_rgb = _hex_to_rgb(accent_color)
        for y in range(720):
            ratio = y / 720.0
            r = int(12 * (1 - ratio) + (accent_rgb[0] // 5) * ratio)
            g = int(17 * (1 - ratio) + (accent_rgb[1] // 5) * ratio)
            b = int(32 * (1 - ratio) + (accent_rgb[2] // 4) * ratio)
            bg_draw.line([(0, y), (1280, y)], fill=(r, g, b, 255))

    # Create dark gradient overlay for crisp text readability
    overlay = Image.new("RGBA", (1280, 720), (0, 0, 0, 0))
    ov_draw = ImageDraw.Draw(overlay)
    for x in range(1280):
        alpha = int(225 * max(0.25, 1.0 - (x / 1150.0) * 0.65))
        ov_draw.line([(x, 0), (x, 720)], fill=(8, 11, 20, alpha))

    composed = Image.alpha_composite(base_img, overlay)
    draw = ImageDraw.Draw(composed)
    accent_rgb = _hex_to_rgb(accent_color)

    # Outer accent frame border
    border_width = 10
    draw.rectangle(
        [border_width // 2, border_width // 2, 1280 - border_width // 2, 720 - border_width // 2],
        outline=(*accent_rgb, 255),
        width=border_width,
    )

    # Top badge pill
    if badge_text:
        badge_font = _load_font(28, bold=True)
        badge_label = badge_text.upper()[:24]
        draw.rounded_rectangle(
            [68, 64, 68 + max(240, len(badge_label) * 20 + 48), 124],
            radius=12,
            fill=(*accent_rgb, 255),
        )
        draw.text((92, 78), badge_label, font=badge_font, fill=(255, 255, 255, 255))

    # Wrap Headline into up to 3 lines of bold impact text
    headline = (headline_text or "NEW YOUTUBE VIDEO").upper()
    words = headline.split()
    lines = []
    curr = ""
    for w in words:
        if len(curr + " " + w) <= 18:
            curr = (curr + " " + w).strip()
        else:
            if curr:
                lines.append(curr)
            curr = w
        if len(lines) == 3:
            break
    if curr and len(lines) < 3:
        lines.append(curr)

    title_font = _load_font(74, bold=True)
    y_cursor = 175
    for idx, line in enumerate(lines):
        # Drop shadow
        draw.text((74, y_cursor + 5), line, font=title_font, fill=(0, 0, 0, 230))
        line_color = (255, 255, 255, 255) if idx < 2 else (*accent_rgb, 255)
        draw.text((70, y_cursor), line, font=title_font, fill=line_color)
        y_cursor += 92

    # Subheadline bar
    if subheadline_text:
        sub_font = _load_font(34, bold=False)
        sub_clean = subheadline_text[:48]
        draw.rounded_rectangle(
            [68, y_cursor + 24, 1180, y_cursor + 94],
            radius=10,
            fill=(255, 255, 255, 28),
            outline=(*accent_rgb, 180),
            width=2,
        )
        draw.text(
            (92, y_cursor + 40),
            sub_clean,
            font=sub_font,
            fill=(235, 242, 255, 255),
        )

    final_rgb = composed.convert("RGB")
    final_rgb.save(out_path, format="PNG", optimize=True)
    if raw_frame.exists():
        try:
            raw_frame.unlink()
        except OSError:
            pass
    return out_path
