import json
import re
from typing import Dict, Any
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.security import decrypt_secret
from app.models.models import AppCredential, Video


def get_active_gemini_config(db: Session) -> tuple[str, str]:
    """
    Returns (api_key, model_name) from either in-app database settings or environment.
    """
    cred = db.query(AppCredential).first()
    if cred and cred.gemini_api_key_enc:
        key = decrypt_secret(cred.gemini_api_key_enc)
        if key:
            return key, (cred.gemini_model or settings.GEMINI_MODEL)
    return settings.GEMINI_API_KEY, settings.GEMINI_MODEL


def generate_seo_for_video(
    db: Session,
    video: Video,
    language: str = "Hinglish",
    custom_prompt: str = "",
    category_id: str = "22",
) -> Dict[str, Any]:
    """
    Uses the official Google GenAI SDK (gemini-2.5-flash) to analyze actual video
    filename, duration, resolution, and transcript/notes to generate:
    - SEO Title + 3 alternative titles
    - Full YouTube description with chapters & hashtags
    - 12+ high-ranking tags & keywords
    - Recommended YouTube Category ID
    Falls back cleanly to deterministic smart metadata generation if no Gemini API key
    is configured yet so the workflow never crashes.
    """
    api_key, model_name = get_active_gemini_config(db)

    clean_stem = (
        re.sub(r"[_\-\.]+", " ", video.original_filename.rsplit(".", 1)[0]).strip()
        or video.title
    )
    duration_min = max(1, round((video.duration_seconds or 60) / 60, 1))

    if api_key:
        try:
            from google import genai
            from google.genai import types

            client = genai.Client(api_key=api_key)
            prompt = f"""
You are an expert YouTube SEO strategist. Analyze the following actual video details and generate accurate, high-CTR YouTube metadata without inventing false facts.

Video Filename / Topic: {clean_stem}
Current Title: {video.title}
Duration: {video.duration_seconds} seconds (~{duration_min} mins)
Resolution: {video.resolution}
Transcript / Notes: {video.transcript_or_notes or 'Standard video content based on topic'}
Target Language / Style: {language}
Additional Instructions: {custom_prompt or 'Optimize for organic YouTube Search and Suggested Videos'}

Return ONLY valid JSON with these exact keys:
{{
  "seo_title": "string (max 95 chars, high CTR, accurate)",
  "alternative_titles": ["string", "string", "string"],
  "description": "string (well-structured description with intro, key takeaways, timestamps, and CTA)",
  "tags": ["tag1", "tag2", "... up to 15 tags"],
  "keywords": ["kw1", "kw2", "..."],
  "hashtags": ["#hashtag1", "#hashtag2", "#hashtag3", "#hashtag4", "#hashtag5"],
  "category_id": "{category_id}",
  "thumbnail_headline": "SHORT 3-5 WORD PUNCHY TEXT"
}}
"""
            response = client.models.generate_content(
                model=model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    temperature=0.6,
                ),
            )
            parsed = json.loads(response.text)
            parsed["ai_model_used"] = model_name
            return parsed
        except Exception as exc:
            # Fall through to smart deterministic generator while recording notice
            fallback_note = f"Gemini fallback ({type(exc).__name__})"
    else:
        fallback_note = "Smart SEO Template (Add Gemini API Key in Settings for live AI)"

    topic_title = clean_stem.title()
    words = [w.lower() for w in re.findall(r"[a-zA-Z0-9]+", clean_stem) if len(w) > 2]
    base_tags = list(dict.fromkeys(words + ["youtube", "trending", "guide", "tutorial", "2026"]))

    if language.lower() in ("hinglish", "hindi"):
        seo_title = f"{topic_title} — Complete Guide & Full Details (Must Watch!)"[:95]
        alt_titles = [
            f"{topic_title} Explained Step by Step!",
            f"{topic_title} | Sab Kuch Jo Aapko Pata Hona Chahiye",
            f"Best {topic_title} Breakdown ({video.resolution} HD)",
        ]
        description = (
            f"Is video mein hum detail mein baat karenge: {topic_title}.\n\n"
            f"📌 Video Highlights:\n"
            f"00:00 - Introduction to {topic_title}\n"
            f"00:30 - Key Concepts & Practical Walkthrough\n"
            f"01:30 - Important Tips & Final Summary\n\n"
            f"{video.transcript_or_notes or 'Agar aapko ye video pasand aaye toh Like, Share aur Channel ko Subscribe zaroor karein!'}\n\n"
            f"#{''.join(words[:2]) or 'youtube'} #trending #hindiguide #viral"
        )
    else:
        seo_title = f"{topic_title}: Complete Breakdown & Step-by-Step Guide"[:95]
        alt_titles = [
            f"Everything You Need to Know About {topic_title}",
            f"{topic_title} — Full Walkthrough & Tips",
            f"How {topic_title} Works (Complete Guide)",
        ]
        description = (
            f"In this video, we cover {topic_title} in full detail.\n\n"
            f"📌 Timestamps:\n"
            f"00:00 - Introduction\n"
            f"00:30 - Core Breakdown: {topic_title}\n"
            f"01:30 - Key Takeaways & Conclusion\n\n"
            f"{video.transcript_or_notes or 'Like, comment, and subscribe for more scheduled videos!'}\n\n"
            f"#{''.join(words[:2]) or 'video'} #youtube #guide"
        )

    hashtags = [f"#{w}" for w in base_tags[:5]]
    return {
        "seo_title": seo_title,
        "alternative_titles": alt_titles,
        "description": description,
        "tags": base_tags[:12],
        "keywords": base_tags[:8],
        "hashtags": hashtags,
        "category_id": category_id or "22",
        "thumbnail_headline": topic_title.upper()[:28],
        "ai_model_used": fallback_note,
    }
