import json
import re
from pathlib import Path
from typing import Dict, Any, List, Optional


def extract_drive_folder_id(link_or_id: str) -> str:
    """
    Extracts the Google Drive folder ID from any Drive URL or raw ID.
    Examples:
      - https://drive.google.com/drive/folders/1AbC_xYz123?usp=sharing -> 1AbC_xYz123
      - https://drive.google.com/drive/u/0/folders/1AbC_xYz123 -> 1AbC_xYz123
      - 1AbC_xYz123 -> 1AbC_xYz123
    """
    raw = (link_or_id or "").strip()
    m = re.search(r"/folders/([a-zA-Z0-9_-]+)", raw)
    if m:
        return m.group(1)
    m2 = re.search(r"[?&]id=([a-zA-Z0-9_-]+)", raw)
    if m2:
        return m2.group(1)
    return raw


def parse_drive_metadata_text(content: str, fallback_title: str = "") -> Dict[str, Any]:
    """
    Parses Title, Description, Tags, and Hashtags from a .txt, .json, or Google Doc
    file stored inside the user's Google Drive folder.
    Supports both JSON format and human-readable labeled format:
      Title: My Video Title
      Description:
      Full description here...
      Tags: tag1, tag2, tag3
    """
    text = (content or "").strip()
    if not text:
        return {}

    # Try JSON first
    if text.startswith("{"):
        try:
            data = json.loads(text)
            tags = data.get("tags", [])
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",") if t.strip()]
            hashtags = data.get("hashtags", [])
            if isinstance(hashtags, str):
                hashtags = [h.strip() for h in hashtags.split() if h.strip()]
            return {
                "seo_title": str(data.get("title") or data.get("seo_title") or fallback_title)[:100],
                "description": str(data.get("description") or ""),
                "tags": tags,
                "hashtags": hashtags,
            }
        except Exception:
            pass

    # Parse labeled text (Title: / Description: / Tags: / Hashtags:)
    lines = text.splitlines()
    title = ""
    desc_lines: List[str] = []
    tags: List[str] = []
    hashtags: List[str] = []
    section = "description"

    for line in lines:
        stripped = line.strip()
        lower = stripped.lower()
        if lower.startswith("title:"):
            title = stripped.split(":", 1)[1].strip()
            section = "title"
        elif lower.startswith("description:") or lower.startswith("desc:"):
            first_part = stripped.split(":", 1)[1].strip()
            if first_part:
                desc_lines.append(first_part)
            section = "description"
        elif lower.startswith("tags:") or lower.startswith("keywords:"):
            raw_tags = stripped.split(":", 1)[1].strip()
            tags = [t.strip() for t in raw_tags.split(",") if t.strip()]
            section = "tags"
        elif lower.startswith("hashtags:"):
            raw_hash = stripped.split(":", 1)[1].strip()
            hashtags = [h.strip() for h in re.split(r"[\s,]+", raw_hash) if h.strip()]
            section = "hashtags"
        else:
            if section == "description":
                desc_lines.append(line)
            elif section == "tags" and stripped:
                tags.extend([t.strip() for t in stripped.split(",") if t.strip()])

    if not title and lines:
        title = lines[0].strip()[:100]

    return {
        "seo_title": (title or fallback_title)[:100],
        "description": "\n".join(desc_lines).strip(),
        "tags": tags,
        "hashtags": hashtags,
    }
