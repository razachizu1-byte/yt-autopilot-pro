import hashlib
import json
import subprocess
from pathlib import Path
from typing import Dict, Any
from app.core.config import VIDEOS_DIR, THUMBNAILS_DIR


def compute_file_sha256(file_path: Path) -> str:
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def inspect_video_file(file_path: Path) -> Dict[str, Any]:
    """
    Uses ffprobe to extract duration, resolution, and file size from a video file.
    """
    if not file_path.exists():
        return {
            "file_size_bytes": 0,
            "duration_seconds": 0,
            "resolution": "1920x1080",
            "file_hash": "",
        }

    file_size = file_path.stat().st_size
    file_hash = compute_file_sha256(file_path)
    duration = 60
    resolution = "1920x1080"

    try:
        cmd = [
            "ffprobe",
            "-v",
            "quiet",
            "-print_format",
            "json",
            "-show_format",
            "-show_streams",
            str(file_path),
        ]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if res.returncode == 0 and res.stdout:
            data = json.loads(res.stdout)
            fmt = data.get("format", {})
            if "duration" in fmt:
                duration = max(1, int(float(fmt["duration"])))
            for stream in data.get("streams", []):
                if stream.get("codec_type") == "video":
                    w = stream.get("width", 1920)
                    h = stream.get("height", 1080)
                    resolution = f"{w}x{h}"
                    break
    except Exception:
        pass

    return {
        "file_size_bytes": file_size,
        "duration_seconds": duration,
        "resolution": resolution,
        "file_hash": file_hash,
    }


def extract_video_frame(
    video_path: Path, output_image_path: Path, timestamp_sec: int = 2
) -> bool:
    """
    Extracts a 1280x720 frame from a video file at timestamp_sec using ffmpeg.
    """
    if not video_path.exists():
        return False
    try:
        cmd = [
            "ffmpeg",
            "-y",
            "-ss",
            str(max(0, timestamp_sec)),
            "-i",
            str(video_path),
            "-frames:v",
            "1",
            "-vf",
            "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720",
            str(output_image_path),
        ]
        res = subprocess.run(cmd, capture_output=True, timeout=20)
        return res.returncode == 0 and output_image_path.exists()
    except Exception:
        return False


def create_sample_mp4(filename: str, duration_sec: int = 5, color: str = "0x1e293b") -> Path:
    """
    Generates a real, valid H.264/AAC MP4 video file using ffmpeg so the user can test
    the complete Drive -> Download -> AI SEO -> Thumbnail -> YouTube Schedule pipeline.
    """
    target = VIDEOS_DIR / filename
    if target.exists():
        return target
    try:
        cmd = [
            "ffmpeg",
            "-y",
            "-f",
            "lavfi",
            "-i",
            f"color=c={color}:s=1280x720:d={duration_sec}",
            "-f",
            "lavfi",
            "-i",
            f"sine=frequency=440:duration={duration_sec}",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-shortest",
            str(target),
        ]
        subprocess.run(cmd, capture_output=True, timeout=25)
    except Exception:
        target.write_bytes(b"\x00\x00\x00\x18ftypmp42")
    return target
