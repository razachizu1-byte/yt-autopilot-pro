import json
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from typing import List, Optional, Dict, Any
from sqlalchemy.orm import Session

from app.models.models import (
    Video,
    SEOMetadata,
    Thumbnail,
    Schedule,
    DriveFolder,
    AutomationSettings,
)
from app.services.ai_seo_service import generate_seo_for_video
from app.services.thumbnail_service import generate_youtube_thumbnail
from app.services.google_service import (
    scan_and_download_drive_folder,
    upload_or_schedule_video_to_youtube,
    log_event,
)


def get_or_create_automation_settings(db: Session) -> AutomationSettings:
    cfg = db.query(AutomationSettings).first()
    if not cfg:
        cfg = AutomationSettings(
            engine_state="RUNNING",
            preset_mode="Full Auto",
            drive_scan_mode="AUTO",
            download_mode="AUTO",
            seo_mode="AUTO",
            thumbnail_mode="AUTO",
            upload_mode="AUTO",
            schedule_mode="AUTO",
            daily_upload_limit=5,
            default_timezone="Asia/Karachi",
            daily_time_slots_json=json.dumps(["10:00", "14:00", "18:00", "21:00"]),
            scan_interval_minutes=15,
            default_privacy="public",
            default_category_id="22",
            default_seo_language="Hinglish",
            use_youtube_native_schedule=True,
        )
        db.add(cfg)
        db.commit()
        db.refresh(cfg)
    return cfg


def ensure_video_has_seo_and_thumbnail(
    db: Session, video: Video, language: str = "Hinglish", category_id: str = "22"
) -> Video:
    """
    Automatically generates AI SEO Metadata and 1280x720 Thumbnail for a video if missing.
    """
    if not video.seo:
        seo_data = generate_seo_for_video(
            db, video, language=language, category_id=category_id
        )
        seo_record = SEOMetadata(
            video_id=video.id,
            seo_title=seo_data["seo_title"],
            alternative_titles_json=json.dumps(seo_data.get("alternative_titles", [])),
            description=seo_data["description"],
            tags_json=json.dumps(seo_data.get("tags", [])),
            keywords_json=json.dumps(seo_data.get("keywords", [])),
            hashtags_json=json.dumps(seo_data.get("hashtags", [])),
            category_id=seo_data.get("category_id", category_id),
            language=language,
            ai_model_used=seo_data.get("ai_model_used", "gemini-2.5-flash"),
            is_approved=True,
        )
        db.add(seo_record)
        video.title = seo_data["seo_title"]
        db.commit()
        db.refresh(video)

    if not video.thumbnail:
        headline = (
            video.seo.seo_title.split("—")[0].split(":")[0].strip()[:32]
            if video.seo
            else video.title[:32]
        )
        thumb_path = generate_youtube_thumbnail(
            video_id=video.id,
            video_path=video.file_path,
            headline_text=headline,
            subheadline_text="FULL BREAKDOWN & GUIDE",
            badge_text="NEW VIDEO",
            accent_color="#FF0033",
        )
        thumb_record = Thumbnail(
            video_id=video.id,
            file_path=str(thumb_path),
            headline_text=headline,
            subheadline_text="FULL BREAKDOWN & GUIDE",
            badge_text="NEW VIDEO",
            accent_color="#FF0033",
        )
        db.add(thumb_record)
        db.commit()
        db.refresh(video)

    return video


def compute_next_available_slots(
    db: Session,
    count: int,
    time_slots: List[str],
    timezone_str: str = "Asia/Karachi",
    daily_limit: int = 5,
    start_date_str: Optional[str] = None,
) -> List[tuple[datetime, str]]:
    """
    Given a user's preferred daily posting times (e.g. ["10:00", "14:00", "18:00", "21:00"]),
    calculates the next `count` available future (UTC datetime, "HH:MM" label) slots
    in the user's chosen timezone, skipping already-booked slots and respecting daily_limit.
    """
    try:
        tz = ZoneInfo(timezone_str)
    except Exception:
        tz = ZoneInfo("UTC")

    cleaned_slots = []
    for s in time_slots:
        s_clean = s.strip()
        if ":" in s_clean:
            parts = s_clean.split(":")
            try:
                hh = max(0, min(23, int(parts[0])))
                mm = max(0, min(59, int(parts[1])))
                cleaned_slots.append(f"{hh:02d}:{mm:02d}")
            except ValueError:
                pass
    if not cleaned_slots:
        cleaned_slots = ["10:00", "15:00", "20:00"]
    cleaned_slots = sorted(list(dict.fromkeys(cleaned_slots)))

    now_local = datetime.now(tz)
    if start_date_str:
        try:
            y, m, d = [int(x) for x in start_date_str.split("-")]
            cursor_date = datetime(y, m, d, tzinfo=tz).date()
        except Exception:
            cursor_date = now_local.date()
    else:
        cursor_date = now_local.date()

    # Load existing scheduled times in UTC
    existing_schedules = db.query(Schedule).filter(
        Schedule.status.in_(["scheduled", "published_scheduled_on_yt", "completed"])
    ).all()

    booked_utc_minutes = set()
    booked_per_local_day: Dict[str, int] = {}
    for sch in existing_schedules:
        dt_utc = sch.scheduled_publish_at
        if dt_utc.tzinfo is None:
            dt_utc = dt_utc.replace(tzinfo=timezone.utc)
        booked_utc_minutes.add(dt_utc.strftime("%Y-%m-%d %H:%M"))
        dt_local = dt_utc.astimezone(tz)
        day_key = dt_local.strftime("%Y-%m-%d")
        booked_per_local_day[day_key] = booked_per_local_day.get(day_key, 0) + 1

    allocated: List[tuple[datetime, str]] = []
    day_offset = 0

    while len(allocated) < count and day_offset < 365:
        target_date = cursor_date + timedelta(days=day_offset)
        day_key = target_date.strftime("%Y-%m-%d")
        used_today = booked_per_local_day.get(day_key, 0)

        for slot_str in cleaned_slots:
            if used_today >= daily_limit:
                break
            hh, mm = [int(x) for x in slot_str.split(":")]
            candidate_local = datetime(
                target_date.year,
                target_date.month,
                target_date.day,
                hh,
                mm,
                0,
                tzinfo=tz,
            )
            # Must be at least 5 minutes in the future
            if candidate_local <= now_local + timedelta(minutes=5):
                continue

            candidate_utc = candidate_local.astimezone(timezone.utc)
            utc_key = candidate_utc.strftime("%Y-%m-%d %H:%M")
            if utc_key in booked_utc_minutes:
                continue

            booked_utc_minutes.add(utc_key)
            used_today += 1
            booked_per_local_day[day_key] = used_today
            allocated.append((candidate_utc, slot_str))
            if len(allocated) >= count:
                break

        day_offset += 1

    return allocated


def schedule_single_video(
    db: Session,
    video: Video,
    scheduled_utc: datetime,
    timezone_str: str = "Asia/Karachi",
    slot_label: str = "",
    privacy_status: str = "public",
    use_youtube_native_schedule: bool = True,
) -> Schedule:
    """
    Schedules a single video for a specific UTC datetime and optionally uploads it
    immediately to YouTube with status.publishAt so YouTube publishes it automatically.
    """
    cfg = get_or_create_automation_settings(db)
    ensure_video_has_seo_and_thumbnail(
        db,
        video,
        language=cfg.default_seo_language,
        category_id=cfg.default_category_id,
    )

    if scheduled_utc.tzinfo is None:
        scheduled_utc = scheduled_utc.replace(tzinfo=timezone.utc)
    else:
        scheduled_utc = scheduled_utc.astimezone(timezone.utc)

    sch = db.query(Schedule).filter(Schedule.video_id == video.id).first()
    if not sch:
        sch = Schedule(video_id=video.id, scheduled_publish_at=scheduled_utc)
        db.add(sch)

    sch.scheduled_publish_at = scheduled_utc
    sch.slot_time_label = slot_label or scheduled_utc.strftime("%H:%M")
    sch.timezone = timezone_str
    sch.privacy_status = privacy_status
    sch.use_youtube_native_schedule = use_youtube_native_schedule
    sch.status = "scheduled"
    sch.last_error = ""
    video.status = "scheduled"
    db.commit()
    db.refresh(sch)

    if use_youtube_native_schedule:
        iso_utc = scheduled_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        upload_or_schedule_video_to_youtube(
            db, video, publish_at_iso_utc=iso_utc, privacy_status=privacy_status
        )
        sch.status = "published_scheduled_on_yt"
        db.commit()

    log_event(
        db,
        "SCHEDULER",
        f"Scheduled '{video.title}' for {scheduled_utc.strftime('%Y-%m-%d %H:%M UTC')} ({timezone_str} slot {sch.slot_time_label})",
        "SUCCESS",
        video.id,
    )
    return sch


def auto_schedule_videos_into_time_slots(
    db: Session,
    video_ids: Optional[List[int]] = None,
    time_slots: Optional[List[str]] = None,
    timezone_str: Optional[str] = None,
    start_date_str: Optional[str] = None,
    privacy_status: str = "public",
    use_youtube_native_schedule: bool = True,
) -> List[Schedule]:
    """
    Automatically assigns pending/ready videos into the user's daily time slots
    (e.g., 10:00 AM, 2:00 PM, 6:00 PM, 9:00 PM) and posts them to YouTube with
    their scheduled publish times!
    """
    cfg = get_or_create_automation_settings(db)
    slots_to_use = time_slots or json.loads(cfg.daily_time_slots_json or '["10:00", "15:00", "20:00"]')
    tz_to_use = timezone_str or cfg.default_timezone or "Asia/Karachi"

    query = db.query(Video)
    if video_ids:
        query = query.filter(Video.id.in_(video_ids))
    else:
        query = query.filter(Video.status.in_(["pending", "ready_for_review"]))
    videos = query.order_by(Video.id.asc()).all()

    if not videos:
        return []

    available_slots = compute_next_available_slots(
        db=db,
        count=len(videos),
        time_slots=slots_to_use,
        timezone_str=tz_to_use,
        daily_limit=cfg.daily_upload_limit,
        start_date_str=start_date_str,
    )

    created_schedules: List[Schedule] = []
    for video, (slot_utc, slot_label) in zip(videos, available_slots):
        sch = schedule_single_video(
            db=db,
            video=video,
            scheduled_utc=slot_utc,
            timezone_str=tz_to_use,
            slot_label=slot_label,
            privacy_status=privacy_status,
            use_youtube_native_schedule=use_youtube_native_schedule,
        )
        created_schedules.append(sch)

    return created_schedules


def run_full_drive_to_youtube_autopilot(db: Session) -> Dict[str, Any]:
    """
    One-click or background worker pipeline that executes the exact workflow requested:
    1. Scans all active Google Drive folders for new videos.
    2. Downloads new videos from Google Drive automatically.
    3. Generates AI SEO (Title, Description, Tags) & HD Thumbnail.
    4. Schedules and posts them to YouTube at the user's configured daily time slots!
    """
    cfg = get_or_create_automation_settings(db)
    folders = db.query(DriveFolder).filter(DriveFolder.auto_scan == True).all()

    downloaded_videos: List[Video] = []
    for folder in folders:
        if cfg.drive_scan_mode == "AUTO":
            new_vids = scan_and_download_drive_folder(
                db, folder, auto_download=(cfg.download_mode == "AUTO")
            )
            downloaded_videos.extend(new_vids)

    # Find all videos ready to be processed/scheduled
    unscheduled_videos = (
        db.query(Video)
        .filter(Video.status.in_(["pending", "ready_for_review"]))
        .order_by(Video.id.asc())
        .all()
    )

    for v in unscheduled_videos:
        if cfg.seo_mode == "AUTO" or cfg.thumbnail_mode == "AUTO":
            ensure_video_has_seo_and_thumbnail(
                db,
                v,
                language=cfg.default_seo_language,
                category_id=cfg.default_category_id,
            )

    scheduled_list: List[Schedule] = []
    if cfg.schedule_mode == "AUTO" and unscheduled_videos:
        scheduled_list = auto_schedule_videos_into_time_slots(
            db=db,
            video_ids=[v.id for v in unscheduled_videos],
            time_slots=json.loads(cfg.daily_time_slots_json or '["10:00", "15:00", "20:00"]'),
            timezone_str=cfg.default_timezone,
            privacy_status=cfg.default_privacy,
            use_youtube_native_schedule=cfg.use_youtube_native_schedule,
        )

    return {
        "folders_scanned": len(folders),
        "new_drive_videos_downloaded": len(downloaded_videos),
        "videos_scheduled_to_youtube": len(scheduled_list),
        "scheduled_video_ids": [s.video_id for s in scheduled_list],
    }
