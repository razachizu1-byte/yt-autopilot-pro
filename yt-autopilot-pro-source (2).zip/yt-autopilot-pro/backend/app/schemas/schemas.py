from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field


class CredentialUpdateRequest(BaseModel):
    google_client_id: Optional[str] = None
    google_client_secret: Optional[str] = None
    google_redirect_uri: Optional[str] = None
    gemini_api_key: Optional[str] = None
    gemini_model: Optional[str] = None


class DriveFolderCreateRequest(BaseModel):
    folder_id: str
    folder_name: str
    account_email: Optional[str] = ""
    auto_scan: bool = True
    auto_download: bool = True
    auto_schedule: bool = True


class SEOMetadataUpdateRequest(BaseModel):
    seo_title: str
    description: str
    tags: List[str] = Field(default_factory=list)
    keywords: List[str] = Field(default_factory=list)
    hashtags: List[str] = Field(default_factory=list)
    category_id: str = "22"
    playlist_id: str = ""
    playlist_name: str = ""
    language: str = "Hinglish"
    is_approved: bool = True


class SEOGenerateRequest(BaseModel):
    language: str = "Hinglish"
    custom_prompt: str = ""
    category_id: str = "22"


class ThumbnailGenerateRequest(BaseModel):
    headline_text: str = ""
    subheadline_text: str = ""
    badge_text: str = "MUST WATCH"
    accent_color: str = "#FF0033"
    template_style: str = "cyber_glow"
    frame_timestamp_sec: int = 2


class ScheduleCreateRequest(BaseModel):
    video_id: int
    scheduled_publish_at: str  # ISO 8601 string or "YYYY-MM-DDTHH:MM"
    timezone: str = "Asia/Karachi"
    privacy_status: str = "public"
    use_youtube_native_schedule: bool = True


class AutoSlotScheduleRequest(BaseModel):
    video_ids: Optional[List[int]] = None
    time_slots: List[str] = Field(default_factory=lambda: ["10:00", "15:00", "20:00"])
    timezone: str = "Asia/Karachi"
    start_date: Optional[str] = None  # YYYY-MM-DD (defaults to today)
    privacy_status: str = "public"
    use_youtube_native_schedule: bool = True


class AutomationSettingsUpdateRequest(BaseModel):
    engine_state: Optional[str] = None
    preset_mode: Optional[str] = None
    drive_scan_mode: Optional[str] = None
    download_mode: Optional[str] = None
    seo_mode: Optional[str] = None
    thumbnail_mode: Optional[str] = None
    upload_mode: Optional[str] = None
    schedule_mode: Optional[str] = None
    daily_upload_limit: Optional[int] = None
    default_timezone: Optional[str] = None
    daily_time_slots: Optional[List[str]] = None
    scan_interval_minutes: Optional[int] = None
    default_privacy: Optional[str] = None
    default_category_id: Optional[str] = None
    default_seo_language: Optional[str] = None
    use_youtube_native_schedule: Optional[bool] = None
