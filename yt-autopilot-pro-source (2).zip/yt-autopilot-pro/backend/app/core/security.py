import base64
import hashlib
from pathlib import Path
from cryptography.fernet import Fernet, InvalidToken
from app.core.config import settings, DATA_DIR


def _get_or_create_fernet_key() -> bytes:
    """
    Returns a valid 32-byte url-safe base64-encoded Fernet key.
    Uses ENCRYPTION_SECRET_KEY if provided in environment, otherwise creates
    and persists a secure local master key in data/.master.key.
    """
    if settings.ENCRYPTION_SECRET_KEY:
        digest = hashlib.sha256(settings.ENCRYPTION_SECRET_KEY.encode("utf-8")).digest()
        return base64.urlsafe_b64encode(digest)

    key_file: Path = DATA_DIR / ".master.key"
    if key_file.exists():
        return key_file.read_bytes().strip()

    key = Fernet.generate_key()
    key_file.write_bytes(key)
    try:
        key_file.chmod(0o600)
    except OSError:
        pass
    return key


_FERNET = Fernet(_get_or_create_fernet_key())


def encrypt_secret(plain_text: str | None) -> str:
    """Encrypts a secret string (OAuth refresh token, API key, client secret)."""
    if not plain_text:
        return ""
    return _FERNET.encrypt(plain_text.encode("utf-8")).decode("utf-8")


def decrypt_secret(cipher_text: str | None) -> str:
    """Decrypts an encrypted secret string."""
    if not cipher_text:
        return ""
    try:
        return _FERNET.decrypt(cipher_text.encode("utf-8")).decode("utf-8")
    except (InvalidToken, ValueError):
        return ""


def mask_secret(secret: str | None) -> str:
    """Masks a secret for safe display in the UI (e.g., 'AIza••••••9x2A')."""
    if not secret:
        return ""
    if len(secret) <= 8:
        return "••••••••"
    return f"{secret[:4]}••••••••{secret[-4:]}"
