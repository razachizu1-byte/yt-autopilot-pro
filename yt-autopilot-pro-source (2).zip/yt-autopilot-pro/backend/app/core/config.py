import os
from pathlib import Path
from pydantic_settings import BaseSettings

BASE_DIR = Path(__file__).resolve().parent.parent.parent
DATA_DIR = BASE_DIR / "data"
VIDEOS_DIR = DATA_DIR / "videos"
THUMBNAILS_DIR = DATA_DIR / "thumbnails"
BACKUPS_DIR = DATA_DIR / "backups"

for directory in (DATA_DIR, VIDEOS_DIR, THUMBNAILS_DIR, BACKUPS_DIR):
    directory.mkdir(parents=True, exist_ok=True)


class Settings(BaseSettings):
    APP_NAME: str = "YT AutoPilot Pro"
    APP_VERSION: str = "1.0.0"
    API_HOST: str = os.getenv("API_HOST", "127.0.0.1")
    API_PORT: int = int(os.getenv("API_PORT", "8765"))
    DEBUG: bool = False

    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", f"sqlite:///{DATA_DIR / 'yt_autopilot.db'}"
    )
    ENCRYPTION_SECRET_KEY: str = os.getenv("ENCRYPTION_SECRET_KEY", "")

    GOOGLE_CLIENT_ID: str = os.getenv("GOOGLE_CLIENT_ID", "")
    GOOGLE_CLIENT_SECRET: str = os.getenv("GOOGLE_CLIENT_SECRET", "")
    GOOGLE_REDIRECT_URI: str = os.getenv(
        "GOOGLE_REDIRECT_URI", "http://127.0.0.1:8765/api/v1/oauth/callback"
    )

    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    DEFAULT_TIMEZONE: str = os.getenv("DEFAULT_TIMEZONE", "Asia/Karachi")
    DEFAULT_DAILY_UPLOAD_LIMIT: int = int(
        os.getenv("DEFAULT_DAILY_UPLOAD_LIMIT", "5")
    )

    class Config:
        env_file = str(BASE_DIR.parent / ".env")
        extra = "ignore"


settings = Settings()
