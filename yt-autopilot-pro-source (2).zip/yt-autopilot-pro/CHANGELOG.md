# Changelog

## [1.0.0] - 2026-11-15
### Added
- Personal Edition of **YT AutoPilot Pro** (no license lockouts).
- In-app **Connect Any Google Drive** manager supporting multiple Drive accounts and folder watching.
- Automatic video download from Google Drive with duplicate `drive_file_id` protection.
- **Daily Posting Time Slots Scheduler** allowing custom daily posting times (e.g. `10:00`, `14:00`, `18:00`, `21:00`) and single-video exact date/time scheduling with YouTube native `publishAt`.
- **AI SEO Studio** (`gemini-2.5-flash`) with Hinglish, Hindi, Urdu, and English support.
- **Thumbnail Studio** (`FFmpeg` + `Pillow`) generating 1280x720 HD YouTube thumbnails.
- In-app `client_secret.json` uploader and Fernet-encrypted credential vault.
- Electron Windows `.exe` configuration and GitHub Actions workflow.
