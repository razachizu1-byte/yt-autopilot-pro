# YT AutoPilot Pro — Development Roadmap

## Phase 1: Project Scaffolding & Database Architecture
- Scaffold `/backend` (FastAPI, SQLAlchemy, Alembic, Pydantic) and `/desktop` (Electron, React, TypeScript, Vite, Tailwind CSS).
- Implement all database models and Alembic migration support (SQLite default + PostgreSQL ready).
- Implement Fernet encryption vault (`app/core/security.py`) for storing OAuth tokens and API keys safely.

## Phase 2: Media, Thumbnail & AI SEO Engines
- Build `media_service.py` using `ffmpeg`/`ffprobe` to inspect video duration, resolution, file size, SHA-256 hash, and extract high-resolution video frames.
- Build `thumbnail_service.py` using `Pillow` to generate 1280x720 YouTube thumbnails with bold typography overlays, gradients, and custom badges.
- Build `ai_seo_service.py` using `google-genai` (`gemini-2.5-flash`) with multi-language support (English, Hindi, Hinglish, Urdu, Spanish) and intelligent metadata analysis.

## Phase 3: Official Google OAuth, Drive & YouTube Services
- Build `google_oauth_service.py` supporting separate Google accounts for **Google Drive** and **YouTube**.
- Build `drive_service.py` to browse folders, scan for new videos, prevent duplicates via `drive_file_id`, and download files.
- Build `youtube_service.py` using YouTube Data API v3 for channel verification, resumable video uploads (`MediaFileUpload`), custom thumbnail uploads, playlist insertion, and native `publishAt` scheduling.

## Phase 4: Scheduler & Automation Engine
- Build `scheduler_service.py` and background worker (`worker.py`) supporting:
  - Single video scheduling with timezone conversion
  - Smart Auto-Slot Bulk Scheduling (automatically distributes videos across upcoming daily slots while respecting daily upload limits)
  - Automation Engine with `Full Auto`, `SEO Auto`, `Upload Auto`, `Manual`, and `Custom` presets and `START / PAUSE / RESUME / STOP` controls.

## Phase 5: Professional Dark Desktop UI (Electron + React)
- Build the complete Personal Edition dark dashboard:
  1. **Dashboard** (Overview cards, quick actions, live queue, activity feed)
  2. **Video Scheduler & Calendar** (Single & bulk auto-slot scheduler, timezone picker, upcoming calendar queue)
  3. **Video Manager** (Import local files/folders, sample test video generator, preview, status filter)
  4. **AI SEO Studio** (Gemini SEO generation in English/Hindi/Hinglish, live editor & approval)
  5. **Thumbnail Studio** (Frame extractor, custom overlay editor, live 16:9 preview & export)
  6. **Upload Manager & History** (Progress tracking, retry failed jobs, YouTube links)
  7. **My YouTube Channel** (OAuth connection, channel stats, default settings)
  8. **Google Drive Sync** (OAuth connection, folder browser, duplicate-safe scanner)
  9. **Automation Engine** (Presets & granular AUTO/MANUAL toggles)
  10. **App Settings & Setup Wizard** (In-app configuration for Google OAuth & Gemini keys with built-in step-by-step setup guide)

## Phase 6: Cloud Deployment, Testing & Windows `.exe` Packaging
- Write comprehensive backend automated tests (`pytest`) covering all APIs, database models, SEO generation, thumbnail rendering, scheduling, and automation engine.
- Configure Electron main process (`electron/main.cjs`), secure preload (`electron/preload.cjs`), custom icon, and `electron-builder.yml`.
- Configure GitHub Actions workflow (`.github/workflows/build-windows.yml`) for automated testing and native Windows `.exe` installer releases.
- Create `Dockerfile` and Cloud Run deployment scripts.
