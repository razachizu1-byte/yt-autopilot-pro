@echo off
title YT AutoPilot Pro - Launcher
echo ========================================================
echo   YT AUTOPILOT PRO - STARTING DESKTOP APPLICATION
echo ========================================================
echo.

cd /d "%~dp0"

if not exist "backend\.venv" (
    echo [1/4] Setting up Python virtual environment...
    python -m venv backend\.venv
    echo [2/4] Installing Python backend dependencies...
    backend\.venv\Scripts\pip install --upgrade pip
    backend\.venv\Scripts\pip install -r backend\requirements.txt
)

if not exist "desktop\node_modules" (
    echo [3/4] Installing Desktop UI dependencies...
    pushd desktop
    call npm install
    call npm run build
    popd
)

echo [4/4] Starting YT AutoPilot Pro Desktop App...
start "YT AutoPilot Backend" /MIN cmd /c "cd /d %~dp0backend && .venv\Scripts\python -m uvicorn app.main:app --host 127.0.0.1 --port 8765"
timeout /t 3 /nobreak >nul
pushd desktop
call npx electron .
popd
