const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  platform: process.platform,
  openExternalUrl: (url) => ipcRenderer.invoke('open-external-url', url),
});
