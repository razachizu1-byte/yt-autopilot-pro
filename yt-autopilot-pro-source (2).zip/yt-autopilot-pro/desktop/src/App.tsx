import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  CalendarClock,
  HardDrive,
  Youtube,
  Film,
  Sparkles,
  Image as ImageIcon,
  Cpu,
  Settings,
  Play,
  Pause,
  RefreshCw,
  Plus,
  Trash2,
  CheckCircle2,
  Clock,
  UploadCloud,
  FolderPlus,
  ExternalLink,
  AlertCircle,
  Zap,
  Check,
} from 'lucide-react';

const API_BASE = '/api/v1';

type TabId =
  | 'dashboard'
  | 'scheduler'
  | 'drive'
  | 'youtube'
  | 'videos'
  | 'seo'
  | 'thumbnail'
  | 'automation'
  | 'settings';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('dashboard');
  const [dash, setDash] = useState<any>(null);
  const [videos, setVideos] = useState<any[]>([]);
  const [browseFolders, setBrowseFolders] = useState<any[]>([]);
  const [creds, setCreds] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [toast, setToast] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Scheduler state (Kis-Kis Time Post Karna Hai)
  const [timeSlots, setTimeSlots] = useState<string[]>(['10:00', '14:00', '18:00', '21:00']);
  const [newSlotInput, setNewSlotInput] = useState<string>('16:30');
  const [selectedTimezone, setSelectedTimezone] = useState<string>('Asia/Karachi');
  const [singleVideoId, setSingleVideoId] = useState<number>(0);
  const [singleDateTime, setSingleDateTime] = useState<string>('');
  const [singlePrivacy, setSinglePrivacy] = useState<string>('public');

  // Drive connect state (Connect Any Google Drive)
  const [quickDriveEmail, setQuickDriveEmail] = useState<string>('');
  const [quickDriveName, setQuickDriveName] = useState<string>('');
  const [customFolderId, setCustomFolderId] = useState<string>('');
  const [customFolderName, setCustomFolderName] = useState<string>('');

  // YouTube connect state
  const [quickYtEmail, setQuickYtEmail] = useState<string>('');
  const [quickYtChannelName, setQuickYtChannelName] = useState<string>('');

  // Selected video for SEO & Thumbnail Studios
  const [selectedVideoId, setSelectedVideoId] = useState<number | null>(null);
  const [seoLanguage, setSeoLanguage] = useState<string>('Hinglish');
  const [seoTitle, setSeoTitle] = useState<string>('');
  const [seoDesc, setSeoDesc] = useState<string>('');
  const [seoTags, setSeoTags] = useState<string>('');
  const [seoHashtags, setSeoHashtags] = useState<string>('');

  // Thumbnail Studio state
  const [thumbHeadline, setThumbHeadline] = useState<string>('');
  const [thumbSubheadline, setThumbSubheadline] = useState<string>('FULL GUIDE & BREAKDOWN');
  const [thumbBadge, setThumbBadge] = useState<string>('MUST WATCH');
  const [thumbColor, setThumbColor] = useState<string>('#FF0033');

  // Settings state
  const [clientIdInput, setClientIdInput] = useState<string>('');
  const [clientSecretInput, setClientSecretInput] = useState<string>('');
  const [geminiKeyInput, setGeminiKeyInput] = useState<string>('');

  const showNotice = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 4500);
  };

  const fetchAllData = async () => {
    try {
      const [dRes, vRes, cRes] = await Promise.all([
        fetch(`${API_BASE}/dashboard`),
        fetch(`${API_BASE}/videos`),
        fetch(`${API_BASE}/credentials`),
      ]);
      if (dRes.ok) {
        const dData = await dRes.json();
        setDash(dData);
        if (dData.automation?.daily_time_slots?.length) {
          setTimeSlots(dData.automation.daily_time_slots);
        }
        if (dData.automation?.default_timezone) {
          setSelectedTimezone(dData.automation.default_timezone);
        }
      }
      if (vRes.ok) {
        const vData = await vRes.json();
        setVideos(vData.videos || []);
        if (!selectedVideoId && vData.videos?.length > 0) {
          selectVideoForStudios(vData.videos[0]);
        }
        if (!singleVideoId && vData.videos?.length > 0) {
          setSingleVideoId(vData.videos[0].id);
        }
      }
      if (cRes.ok) {
        const cData = await cRes.json();
        setCreds(cData);
        setClientIdInput(cData.google_client_id || '');
      }
    } catch (err) {
      console.error('Error loading data:', err);
    }
  };

  const selectVideoForStudios = (v: any) => {
    setSelectedVideoId(v.id);
    setSeoTitle(v.seo?.seo_title || v.title || '');
    setSeoDesc(v.seo?.description || '');
    setSeoTags((v.seo?.tags || []).join(', '));
    setSeoHashtags((v.seo?.hashtags || []).join(' '));
    setSeoLanguage(v.seo?.language || 'Hinglish');
    setThumbHeadline(v.thumbnail?.headline_text || (v.title || '').slice(0, 28).toUpperCase());
    setThumbSubheadline(v.thumbnail?.subheadline_text || 'COMPLETE STEP-BY-STEP');
    setThumbBadge(v.thumbnail?.badge_text || 'NEW VIDEO');
    setThumbColor(v.thumbnail?.accent_color || '#FF0033');
  };

  useEffect(() => {
    fetchAllData();
    const now = new Date(Date.now() + 3600 * 1000 * 3);
    setSingleDateTime(now.toISOString().slice(0, 16));
  }, []);

  // ========================================================
  // KEY ACTIONS
  // ========================================================

  const handleRunFullAutopilotNow = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/drive/scan?auto_schedule_after_download=true`, {
        method: 'POST',
      });
      const data = await res.json();
      await fetchAllData();
      showNotice(
        `Autopilot Complete! Downloaded ${data.downloaded_count} video(s) from Drive & scheduled ${data.scheduled_count} video(s) to YouTube time slots!`,
        'success'
      );
    } catch (e) {
      showNotice('Failed to run autopilot pipeline', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleAddTimeSlot = async () => {
    if (!newSlotInput || timeSlots.includes(newSlotInput)) return;
    const updated = [...timeSlots, newSlotInput].sort();
    setTimeSlots(updated);
    await fetch(`${API_BASE}/automation`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        daily_time_slots: updated,
        default_timezone: selectedTimezone,
      }),
    });
    await fetchAllData();
    showNotice(`Added daily posting time slot: ${newSlotInput} (${selectedTimezone})`);
  };

  const handleRemoveTimeSlot = async (slot: string) => {
    const updated = timeSlots.filter((s) => s !== slot);
    setTimeSlots(updated);
    await fetch(`${API_BASE}/automation`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ daily_time_slots: updated }),
    });
    await fetchAllData();
    showNotice(`Removed time slot ${slot}`);
  };

  const handleAutoScheduleAllToSlots = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/schedules/auto-slots`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          time_slots: timeSlots,
          timezone: selectedTimezone,
          privacy_status: singlePrivacy,
          use_youtube_native_schedule: true,
        }),
      });
      const data = await res.json();
      await fetchAllData();
      showNotice(
        `Scheduled ${data.scheduled_count} video(s) across your daily times (${timeSlots.join(', ')})!`
      );
    } finally {
      setLoading(false);
    }
  };

  const handleScheduleSingleVideo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!singleVideoId || !singleDateTime) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/schedules/single`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          video_id: Number(singleVideoId),
          scheduled_publish_at: singleDateTime,
          timezone: selectedTimezone,
          privacy_status: singlePrivacy,
          use_youtube_native_schedule: true,
        }),
      });
      if (res.ok) {
        await fetchAllData();
        showNotice('Video scheduled on YouTube for exact date & time!');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleConnectGoogleOAuth = async (purpose: 'drive' | 'youtube') => {
    const res = await fetch(`${API_BASE}/oauth/url?purpose=${purpose}`);
    const data = await res.json();
    if (data.configured && data.auth_url) {
      window.open(data.auth_url, '_blank');
      showNotice(`Opened Google Sign-In for ${purpose.toUpperCase()} in browser!`, 'info');
    } else {
      showNotice(
        'Google Client ID not added yet — use Quick Connect below or upload client_secret.json in Settings!',
        'info'
      );
    }
  };

  const handleQuickConnectAccount = async (purpose: 'drive' | 'youtube') => {
    const email =
      purpose === 'drive'
        ? quickDriveEmail.trim() || 'my.videos.drive@gmail.com'
        : quickYtEmail.trim() || 'my.youtube.creator@gmail.com';
    const displayName =
      purpose === 'drive'
        ? quickDriveName.trim() || email.split('@')[0]
        : quickYtChannelName.trim() || 'My YouTube Channel';

    const form = new FormData();
    form.append('purpose', purpose);
    form.append('email', email);
    form.append('display_name', displayName);
    form.append('channel_title', displayName);

    const res = await fetch(`${API_BASE}/accounts/connect-quick`, {
      method: 'POST',
      body: form,
    });
    if (res.ok) {
      setQuickDriveEmail('');
      setQuickDriveName('');
      setQuickYtEmail('');
      setQuickYtChannelName('');
      await fetchAllData();
      showNotice(`Connected ${purpose.toUpperCase()} account: ${email}`);
    }
  };

  const handleDisconnectAccount = async (id: number) => {
    await fetch(`${API_BASE}/accounts/${id}`, { method: 'DELETE' });
    await fetchAllData();
    showNotice('Account disconnected. You can connect any new Google account anytime!');
  };

  const handleBrowseDriveFolders = async () => {
    const res = await fetch(`${API_BASE}/drive/browse`);
    if (res.ok) {
      const data = await res.json();
      setBrowseFolders(data.folders || []);
    }
  };

  const handleAddWatchedFolder = async (folderId: string, folderName: string, email: string) => {
    if (!folderId || !folderName) return;
    await fetch(`${API_BASE}/drive/folders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        folder_id: folderId,
        folder_name: folderName,
        account_email: email,
        auto_scan: true,
        auto_download: true,
        auto_schedule: true,
      }),
    });
    setCustomFolderId('');
    setCustomFolderName('');
    await fetchAllData();
    showNotice(`Added Drive folder "${folderName}" for auto-download & YouTube scheduling!`);
  };

  const handleLocalVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      form.append('auto_seo_and_schedule', 'true');
      const res = await fetch(`${API_BASE}/videos/upload-local`, {
        method: 'POST',
        body: form,
      });
      if (res.ok) {
        await fetchAllData();
        showNotice(`Imported "${file.name}", generated AI SEO & scheduled to next time slot!`);
      } else {
        const err = await res.json();
        showNotice(err.detail || 'Upload failed', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateSEO = async () => {
    if (!selectedVideoId) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/videos/${selectedVideoId}/seo`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ language: seoLanguage, category_id: '22' }),
      });
      if (res.ok) {
        const data = await res.json();
        selectVideoForStudios(data.video);
        await fetchAllData();
        showNotice(`AI SEO generated in ${seoLanguage}!`);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSEO = async () => {
    if (!selectedVideoId) return;
    const res = await fetch(`${API_BASE}/videos/${selectedVideoId}/seo`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        seo_title: seoTitle,
        description: seoDesc,
        tags: seoTags
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean),
        keywords: [],
        hashtags: seoHashtags
          .split(/\s+/)
          .map((h) => h.trim())
          .filter(Boolean),
        category_id: '22',
        language: seoLanguage,
        is_approved: true,
      }),
    });
    if (res.ok) {
      await fetchAllData();
      showNotice('SEO Title, Description & Tags saved!');
    }
  };

  const handleGenerateThumbnail = async () => {
    if (!selectedVideoId) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/videos/${selectedVideoId}/thumbnail`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          headline_text: thumbHeadline,
          subheadline_text: thumbSubheadline,
          badge_text: thumbBadge,
          accent_color: thumbColor,
          frame_timestamp_sec: 2,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        selectVideoForStudios(data.video);
        await fetchAllData();
        showNotice('Generated 1280x720 HD YouTube Thumbnail!');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUploadClientSecretJson = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append('file', file);
    const res = await fetch(`${API_BASE}/credentials/upload-client-secret`, {
      method: 'POST',
      body: form,
    });
    if (res.ok) {
      await fetchAllData();
      showNotice('client_secret.json uploaded & encrypted! You can now connect any Google account via OAuth.');
    } else {
      showNotice('Invalid client_secret.json file', 'error');
    }
  };

  const handleSaveCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch(`${API_BASE}/credentials`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        google_client_id: clientIdInput,
        google_client_secret: clientSecretInput,
        gemini_api_key: geminiKeyInput,
      }),
    });
    if (res.ok) {
      setClientSecretInput('');
      setGeminiKeyInput('');
      await fetchAllData();
      showNotice('Credentials encrypted & saved inside app!');
    }
  };

  const selectedVideo = videos.find((v) => v.id === selectedVideoId) || videos[0] || null;
  const counts = dash?.counts || {
    total: 0,
    pending: 0,
    processing: 0,
    scheduled: 0,
    uploaded: 0,
    failed: 0,
  };

  const navItems: { id: TabId; label: string; sub: string; icon: any }[] = [
    { id: 'dashboard', label: 'Dashboard', sub: 'Overview & 1-Click Run', icon: LayoutDashboard },
    { id: 'scheduler', label: 'YouTube Scheduler', sub: 'Kis-Kis Time Post Karna Hai', icon: CalendarClock },
    { id: 'drive', label: 'Google Drive Sync', sub: 'Connect Any Drive & Folders', icon: HardDrive },
    { id: 'youtube', label: 'My YouTube Channel', sub: 'Connect Channel & Privacy', icon: Youtube },
    { id: 'videos', label: 'Video Manager', sub: 'Downloaded & Local Videos', icon: Film },
    { id: 'seo', label: 'AI SEO Studio', sub: 'Titles, Description & Tags', icon: Sparkles },
    { id: 'thumbnail', label: 'Thumbnail Studio', sub: '1280x720 HD Creator', icon: ImageIcon },
    { id: 'automation', label: 'Automation Rules', sub: 'Auto vs Manual Controls', icon: Cpu },
    { id: 'settings', label: 'App Setup & Keys', sub: 'Google OAuth & Gemini Key', icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-[#0B0F19] text-slate-100 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-72 bg-[#111827] border-r border-slate-800/80 flex flex-col justify-between shrink-0">
        <div>
          <div className="p-5 border-b border-slate-800/80 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-rose-600 to-red-700 flex items-center justify-center shadow-lg shadow-rose-600/30">
              <Youtube className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-base tracking-tight text-white flex items-center gap-1.5">
                YT AutoPilot <span className="text-xs px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-400 font-semibold">PRO</span>
              </h1>
              <p className="text-xs text-slate-400">Drive to YouTube Auto-Scheduler</p>
            </div>
          </div>

          <nav className="p-3 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    if (item.id === 'drive') handleBrowseDriveFolders();
                  }}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-left transition-all ${
                    active
                      ? 'bg-gradient-to-r from-rose-600/20 to-blue-600/10 border border-rose-500/40 text-white shadow-sm'
                      : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                  }`}
                >
                  <Icon className={`w-5 h-5 shrink-0 ${active ? 'text-rose-400' : 'text-slate-400'}`} />
                  <div className="overflow-hidden">
                    <div className="text-sm font-medium truncate">{item.label}</div>
                    <div className="text-[11px] text-slate-500 truncate">{item.sub}</div>
                  </div>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Engine Status Card */}
        <div className="p-4 m-3 rounded-xl bg-slate-900/90 border border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-slate-400">AUTOPILOT ENGINE</span>
            <span
              className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                dash?.automation?.engine_state === 'RUNNING'
                  ? 'bg-emerald-500/20 text-emerald-400'
                  : 'bg-amber-500/20 text-amber-400'
              }`}
            >
              {dash?.automation?.engine_state || 'RUNNING'}
            </span>
          </div>
          <div className="text-xs text-slate-400 mb-3">
            Daily Times:{' '}
            <span className="text-slate-200 font-semibold">{timeSlots.join(', ')}</span>
          </div>
          <button
            onClick={handleRunFullAutopilotNow}
            disabled={loading}
            className="w-full py-2 px-3 rounded-lg bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-rose-600/25 transition"
          >
            <Zap className="w-4 h-4" />
            {loading ? 'Running Autopilot...' : 'Sync Drive & Schedule Now'}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-16 bg-[#111827]/90 border-b border-slate-800/80 px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg">
              <HardDrive className="w-4 h-4 text-blue-400" />
              <span className="text-slate-400">Drive:</span>
              {dash?.drive_accounts?.length > 0 ? (
                <span className="text-emerald-400 font-medium">
                  {dash.drive_accounts[0].email} ({dash.drive_accounts.length} connected)
                </span>
              ) : (
                <button
                  onClick={() => setActiveTab('drive')}
                  className="text-amber-400 underline font-medium"
                >
                  Click to Connect Any Drive
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs bg-slate-900 border border-slate-800 px-3 py-1.5 rounded-lg">
              <Youtube className="w-4 h-4 text-rose-500" />
              <span className="text-slate-400">YouTube:</span>
              {dash?.youtube_channel ? (
                <span className="text-emerald-400 font-medium">
                  {dash.youtube_channel.title}
                </span>
              ) : (
                <button
                  onClick={() => setActiveTab('youtube')}
                  className="text-amber-400 underline font-medium"
                >
                  Click to Connect Channel
                </button>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <a
              href="/api/v1/download-windows-exe"
              download="YT-AutoPilot-Pro-Windows-x64.zip"
              className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md"
            >
              <UploadCloud className="w-3.5 h-3.5" />
              Download Windows App (.exe)
            </a>
            <a
              href="/api/v1/download-project-zip"
              download="yt-autopilot-pro-full.zip"
              className="px-3.5 py-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-1.5"
            >
              Source (.zip)
            </a>
            <button
              onClick={() => setActiveTab('scheduler')}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5"
            >
              <Clock className="w-3.5 h-3.5 text-blue-400" />
              Posting Times ({timeSlots.length}/day)
            </button>
            <button
              onClick={handleRunFullAutopilotNow}
              disabled={loading}
              className="px-4 py-1.5 rounded-lg bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Auto-Download from Drive & Schedule
            </button>
          </div>
        </header>

        {/* Toast Notification */}
        {toast && (
          <div
            className={`mx-6 mt-4 px-4 py-3 rounded-xl border flex items-center justify-between text-sm ${
              toast.type === 'error'
                ? 'bg-red-950/80 border-red-500/50 text-red-200'
                : toast.type === 'info'
                ? 'bg-blue-950/80 border-blue-500/50 text-blue-200'
                : 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{toast.text}</span>
            </div>
            <button onClick={() => setToast(null)} className="text-xs opacity-70 hover:opacity-100">
              Dismiss
            </button>
          </div>
        )}

        {/* Scrollable Workspace */}
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* ========================================================
              TAB 1: DASHBOARD
             ======================================================== */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* Hero Action Banner */}
              <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-[#151F32] to-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <span className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30 mb-2">
                    <Zap className="w-3.5 h-3.5" /> PERSONAL YOUTUBE AUTOPILOT
                  </span>
                  <h2 className="text-xl font-bold text-white">
                    Google Drive Auto-Download &rarr; AI SEO &rarr; YouTube Multi-Time Scheduler
                  </h2>
                  <p className="text-sm text-slate-400 mt-1">
                    Connect any Google Drive folder, set your daily posting times ({timeSlots.join(', ')}), and let the app download & schedule videos to YouTube automatically.
                  </p>
                </div>
                <div className="flex flex-wrap gap-2.5 shrink-0">
                  <button
                    onClick={() => {
                      setActiveTab('drive');
                      handleBrowseDriveFolders();
                    }}
                    className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-2"
                  >
                    <HardDrive className="w-4 h-4" /> Connect Any Drive
                  </button>
                  <button
                    onClick={() => setActiveTab('scheduler')}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white text-xs font-semibold flex items-center gap-2"
                  >
                    <CalendarClock className="w-4 h-4 text-rose-400" /> Set Posting Times
                  </button>
                </div>
              </div>

              {/* Status Counters */}
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                {[
                  { label: 'Total Videos', val: counts.total, color: 'text-white' },
                  { label: 'Ready / Pending', val: counts.pending, color: 'text-amber-400' },
                  { label: 'Scheduled on YT', val: counts.scheduled, color: 'text-blue-400' },
                  { label: 'Uploaded Live', val: counts.uploaded, color: 'text-emerald-400' },
                  { label: 'Processing', val: counts.processing, color: 'text-purple-400' },
                  { label: 'Failed', val: counts.failed, color: 'text-rose-400' },
                ].map((c, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-[#111827] border border-slate-800/90"
                  >
                    <div className="text-xs text-slate-400">{c.label}</div>
                    <div className={`text-2xl font-bold mt-1 ${c.color}`}>{c.val}</div>
                  </div>
                ))}
              </div>

              {/* Scheduled Videos & Activity Logs */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-[#111827] border border-slate-800 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-base flex items-center gap-2">
                      <CalendarClock className="w-5 h-5 text-rose-500" />
                      Videos Downloaded & Scheduled for YouTube
                    </h3>
                    <button
                      onClick={() => setActiveTab('scheduler')}
                      className="text-xs text-blue-400 hover:underline"
                    >
                      Manage Time Slots &rarr;
                    </button>
                  </div>

                  {videos.length === 0 ? (
                    <div className="text-center py-10 text-slate-400 text-sm">
                      No videos yet. Click <b>"Auto-Download from Drive & Schedule"</b> in the top bar to test immediately!
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {videos.slice(0, 8).map((v) => (
                        <div
                          key={v.id}
                          className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-4"
                        >
                          <div className="flex items-center gap-3.5 min-w-0">
                            {v.thumbnail?.image_url ? (
                              <img
                                src={v.thumbnail.image_url}
                                alt={v.title}
                                className="w-24 h-14 object-cover rounded-lg border border-slate-700 shrink-0"
                              />
                            ) : (
                              <div className="w-24 h-14 rounded-lg bg-slate-800 flex items-center justify-center shrink-0">
                                <Film className="w-5 h-5 text-slate-500" />
                              </div>
                            )}
                            <div className="min-w-0">
                              <div className="font-semibold text-sm text-white truncate">
                                {v.title}
                              </div>
                              <div className="text-xs text-slate-400 flex flex-wrap items-center gap-2 mt-1">
                                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                                  Source: {v.source_type === 'drive' ? 'Google Drive' : 'Local'}
                                </span>
                                {v.schedule && (
                                  <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-medium">
                                    ⏰ Scheduled: {v.schedule.local_display} ({v.schedule.slot_time_label})
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <span
                              className={`text-xs px-2.5 py-1 rounded-full font-semibold ${
                                v.status === 'scheduled'
                                  ? 'bg-blue-500/20 text-blue-400'
                                  : v.status === 'uploaded'
                                  ? 'bg-emerald-500/20 text-emerald-400'
                                  : 'bg-amber-500/20 text-amber-400'
                              }`}
                            >
                              {v.status.toUpperCase()}
                            </span>
                            <button
                              onClick={() => {
                                selectVideoForStudios(v);
                                setActiveTab('seo');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200"
                            >
                              Edit SEO
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Activity Log Feed */}
                <div className="bg-[#111827] border border-slate-800 rounded-2xl p-5">
                  <h3 className="font-bold text-base mb-4">Live Autopilot Activity</h3>
                  <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
                    {(dash?.activity_logs || []).map((log: any) => (
                      <div
                        key={log.id}
                        className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800/80 text-xs"
                      >
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                          <span className="font-bold text-rose-400">{log.category}</span>
                          <span>{new Date(log.created_at).toLocaleTimeString()}</span>
                        </div>
                        <div className="text-slate-200">{log.message}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 2: YOUTUBE SCHEDULER (KIS-KIS TIME POST KARNA HAI)
             ======================================================== */}
          {activeTab === 'scheduler' && (
            <div className="space-y-6">
              {/* Paste Google Drive Link (Video + Thumbnail + Title/Desc/Tags) */}
              <div className="bg-gradient-to-r from-[#111827] to-[#162033] border border-blue-500/30 rounded-2xl p-6">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <HardDrive className="w-5 h-5 text-blue-400" />
                  Paste Google Drive Folder Link (Video + Thumbnail + Title/Desc/Tags)
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Paste any Google Drive folder link that contains your <b>Video</b>, <b>Thumbnail image</b>, and <b>Title/Description/Tags (.txt/.json/Doc)</b>. The app will download all of them and schedule automatically into your next time slot!
                </p>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-4 items-center">
                  <input
                    type="text"
                    placeholder="https://drive.google.com/drive/folders/..."
                    value={driveLinkInput}
                    onChange={(e) => setDriveLinkInput(e.target.value)}
                    className="md:col-span-3 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white"
                  />
                  <button
                    onClick={async () => {
                      if (!driveLinkInput.trim()) {
                        showNotice('Please paste a Google Drive folder link first!', 'error');
                        return;
                      }
                      setLoading(true);
                      try {
                        const form = new FormData();
                        form.append('drive_link', driveLinkInput.trim());
                        form.append('timezone_str', selectedTimezone);
                        form.append('privacy_status', singlePrivacy);
                        const res = await fetch(`${API_BASE}/schedules/from-drive-link`, {
                          method: 'POST',
                          body: form,
                        });
                        const data = await res.json();
                        await fetchAllData();
                        setDriveLinkInput('');
                        showNotice(
                          `Fetched ${data.downloaded_count} video(s) + Thumbnail/Metadata from Drive Link & Scheduled ${data.scheduled_count} on YouTube!`
                        );
                      } finally {
                        setLoading(false);
                      }
                    }}
                    disabled={loading}
                    className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center justify-center gap-2"
                  >
                    <Zap className="w-4 h-4" /> Fetch Drive Link & Schedule
                  </button>
                </div>
              </div>

              <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <CalendarClock className="w-5 h-5 text-rose-500" />
                  Daily YouTube Posting Time Slots (Kis-Kis Time Video Post Karni Hai)
                </h2>
                <p className="text-sm text-slate-400 mt-1">
                  Set the exact times of day when you want videos published on YouTube. Whenever new videos are downloaded from Google Drive, YT AutoPilot Pro automatically assigns them to the next open time slot!
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-5">
                  {/* Current Daily Time Slots */}
                  <div className="md:col-span-2 space-y-4">
                    <div className="flex flex-wrap gap-2.5">
                      {timeSlots.map((slot) => (
                        <div
                          key={slot}
                          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 border border-blue-500/40 text-white font-semibold text-sm"
                        >
                          <Clock className="w-4 h-4 text-blue-400" />
                          <span>{slot}</span>
                          <button
                            onClick={() => handleRemoveTimeSlot(slot)}
                            className="text-slate-400 hover:text-rose-400 ml-1"
                            title="Remove slot"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 pt-2">
                      <input
                        type="time"
                        value={newSlotInput}
                        onChange={(e) => setNewSlotInput(e.target.value)}
                        className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-sm"
                      />
                      <button
                        onClick={handleAddTimeSlot}
                        className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4" /> Add Posting Time
                      </button>

                      <select
                        value={selectedTimezone}
                        onChange={(e) => setSelectedTimezone(e.target.value)}
                        className="px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs"
                      >
                        <option value="Asia/Karachi">Pakistan Time (Asia/Karachi - PKT)</option>
                        <option value="Asia/Kolkata">India Time (Asia/Kolkata - IST)</option>
                        <option value="Asia/Dubai">UAE Time (Asia/Dubai - GST)</option>
                        <option value="Europe/London">UK Time (Europe/London)</option>
                        <option value="America/New_York">USA Eastern (America/New_York)</option>
                        <option value="UTC">UTC</option>
                      </select>
                    </div>
                  </div>

                  {/* 1-Click Auto-Assign Box */}
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between">
                    <div>
                      <div className="text-xs font-semibold text-rose-400 uppercase">
                        Auto-Slot Scheduler
                      </div>
                      <p className="text-xs text-slate-400 mt-1">
                        Automatically schedule all unscheduled videos into the daily time slots above and set YouTube's official <code>publishAt</code> timer.
                      </p>
                    </div>
                    <button
                      onClick={handleAutoScheduleAllToSlots}
                      disabled={loading}
                      className="mt-4 w-full py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                    >
                      <CalendarClock className="w-4 h-4" />
                      Auto-Schedule All Videos to Slots
                    </button>
                  </div>
                </div>
              </div>

              {/* Manual Single Video Date & Time Picker */}
              <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6">
                <h3 className="font-bold text-base mb-4">
                  Or Schedule a Specific Video for Any Exact Date & Time
                </h3>
                <form
                  onSubmit={handleScheduleSingleVideo}
                  className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end"
                >
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Select Video</label>
                    <select
                      value={singleVideoId}
                      onChange={(e) => setSingleVideoId(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                    >
                      {videos.map((v) => (
                        <option key={v.id} value={v.id}>
                          #{v.id} - {v.title.slice(0, 45)}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Publish Date & Time ({selectedTimezone})
                    </label>
                    <input
                      type="datetime-local"
                      value={singleDateTime}
                      onChange={(e) => setSingleDateTime(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Privacy When Published
                    </label>
                    <select
                      value={singlePrivacy}
                      onChange={(e) => setSinglePrivacy(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                    >
                      <option value="public">Public (Recommended)</option>
                      <option value="unlisted">Unlisted</option>
                      <option value="private">Private</option>
                    </select>
                  </div>
                  <button
                    type="submit"
                    className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                  >
                    <Check className="w-4 h-4" /> Schedule This Video on YouTube
                  </button>
                </form>
              </div>

              {/* Scheduled Calendar Queue */}
              <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6">
                <h3 className="font-bold text-base mb-4">
                  Upcoming Scheduled YouTube Queue ({videos.filter((v) => v.schedule).length})
                </h3>
                <div className="space-y-3">
                  {videos
                    .filter((v) => v.schedule)
                    .map((v) => (
                      <div
                        key={v.id}
                        className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-4">
                          {v.thumbnail?.image_url && (
                            <img
                              src={v.thumbnail.image_url}
                              alt={v.title}
                              className="w-28 h-16 object-cover rounded-lg border border-slate-700"
                            />
                          )}
                          <div>
                            <div className="font-bold text-sm text-white">{v.title}</div>
                            <div className="text-xs text-blue-400 font-medium mt-1">
                              📅 Publishes: {v.schedule.local_display} ({v.schedule.timezone}) — Slot{' '}
                              {v.schedule.slot_time_label}
                            </div>
                            <div className="text-[11px] text-slate-400 mt-0.5">
                              YouTube Native <code>publishAt</code> Active • Final Privacy:{' '}
                              <span className="uppercase text-emerald-400">
                                {v.schedule.privacy_status}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {v.youtube_url && (
                            <a
                              href={v.youtube_url}
                              target="_blank"
                              rel="noreferrer"
                              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 flex items-center gap-1"
                            >
                              <ExternalLink className="w-3.5 h-3.5" /> YouTube Studio Link
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 3: CONNECT ANY GOOGLE DRIVE (INSIDE THE APP)
             ======================================================== */}
          {activeTab === 'drive' && (
            <div className="space-y-6">
              <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-800">
                  <div>
                    <h2 className="text-lg font-bold text-white flex items-center gap-2">
                      <HardDrive className="w-5 h-5 text-blue-400" />
                      Connect Any Google Drive Account Inside the App
                    </h2>
                    <p className="text-sm text-slate-400 mt-1">
                      You can connect <b>any Google Drive account</b> (or multiple Drive accounts) and switch accounts anytime. Videos placed in your watched Drive folders are automatically downloaded and scheduled on YouTube!
                    </p>
                  </div>
                  <button
                    onClick={() => handleConnectGoogleOAuth('drive')}
                    className="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-2 shrink-0 shadow-lg shadow-blue-600/25"
                  >
                    <HardDrive className="w-4 h-4" />
                    Sign In with Any Google Drive (OAuth)
                  </button>
                </div>

                {/* Quick Connect Any Drive Email */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-5 items-end">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Google Drive Email (Connect / Switch Any Drive)
                    </label>
                    <input
                      type="email"
                      placeholder="e.g. my.second.drive@gmail.com"
                      value={quickDriveEmail}
                      onChange={(e) => setQuickDriveEmail(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Account Label / Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Main Video Storage Drive"
                      value={quickDriveName}
                      onChange={(e) => setQuickDriveName(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                  <button
                    onClick={() => handleQuickConnectAccount('drive')}
                    className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" /> Connect / Add This Drive Account
                  </button>
                </div>

                {/* Connected Drive Accounts List */}
                <div className="mt-6 space-y-2.5">
                  <div className="text-xs font-semibold text-slate-400 uppercase">
                    Connected Google Drive Accounts ({dash?.drive_accounts?.length || 0})
                  </div>
                  {(dash?.drive_accounts || []).map((acc: any) => (
                    <div
                      key={acc.id}
                      className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-bold text-sm">
                          {acc.email[0]?.toUpperCase()}
                        </div>
                        <div>
                          <div className="font-semibold text-sm text-white">
                            {acc.display_name} ({acc.email})
                          </div>
                          <div className="text-xs text-emerald-400">
                            ● Active Drive Source — Ready to scan & download videos
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDisconnectAccount(acc.id)}
                        className="px-3 py-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 text-xs font-medium"
                      >
                        Disconnect / Switch
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Select & Watch Drive Folders */}
              <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-base">
                      Watched Google Drive Folders (Auto-Download & Schedule)
                    </h3>
                    <p className="text-xs text-slate-400">
                      Select a folder from your Drive or paste any Google Drive Folder ID/Name below.
                    </p>
                  </div>
                  <button
                    onClick={handleRunFullAutopilotNow}
                    disabled={loading}
                    className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <UploadCloud className="w-4 h-4" /> Scan Drive & Auto-Download Now
                  </button>
                </div>

                {/* Add Any Custom Drive Folder ID */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-5 p-4 rounded-xl bg-slate-900/70 border border-slate-800">
                  <input
                    type="text"
                    placeholder="Drive Folder ID or Link (e.g. 1A2b3C_folder_id)"
                    value={customFolderId}
                    onChange={(e) => setCustomFolderId(e.target.value)}
                    className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                  />
                  <input
                    type="text"
                    placeholder="Folder Name (e.g. Daily Shorts Folder)"
                    value={customFolderName}
                    onChange={(e) => setCustomFolderName(e.target.value)}
                    className="px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white"
                  />
                  <button
                    onClick={() =>
                      handleAddWatchedFolder(
                        customFolderId || `folder_${Date.now()}`,
                        customFolderName || 'My Custom Drive Folder',
                        dash?.drive_accounts?.[0]?.email || 'my.drive@gmail.com'
                      )
                    }
                    className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <FolderPlus className="w-4 h-4" /> Watch This Drive Folder
                  </button>
                </div>

                {/* Available Folders from Browser */}
                {browseFolders.length > 0 && (
                  <div className="mb-5">
                    <div className="text-xs font-semibold text-slate-400 mb-2">
                      Available Folders in Connected Drive (Click to Watch):
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {browseFolders.map((bf) => (
                        <div
                          key={bf.id}
                          className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                        >
                          <div className="truncate pr-2">
                            <div className="text-xs font-semibold text-white truncate">
                              📁 {bf.name}
                            </div>
                            <div className="text-[11px] text-slate-400">{bf.account_email}</div>
                          </div>
                          <button
                            onClick={() =>
                              handleAddWatchedFolder(bf.id, bf.name, bf.account_email)
                            }
                            className="px-2.5 py-1 rounded-lg bg-blue-600/20 hover:bg-blue-600/40 text-blue-300 text-xs font-medium shrink-0"
                          >
                            + Select
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Active Watched Folders */}
                <div className="space-y-2.5">
                  {(dash?.drive_folders || []).map((f: any) => (
                    <div
                      key={f.id}
                      className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-sm text-white">
                          📁 {f.folder_name}{' '}
                          <span className="text-xs text-slate-400 font-normal">
                            ({f.folder_id})
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 mt-1">
                          Auto-Scan: <b className="text-emerald-400">ON</b> • Auto-Download:{' '}
                          <b className="text-emerald-400">ON</b> • Auto-Schedule to YouTube:{' '}
                          <b className="text-emerald-400">ON</b> • Videos Found:{' '}
                          <b>{f.videos_found}</b>
                        </div>
                      </div>
                      <button
                        onClick={async () => {
                          await fetch(`${API_BASE}/drive/folders/${f.id}`, {
                            method: 'DELETE',
                          });
                          await fetchAllData();
                        }}
                        className="text-slate-400 hover:text-rose-400 p-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 4: MY YOUTUBE CHANNEL
             ======================================================== */}
          {activeTab === 'youtube' && (
            <div className="space-y-6">
              <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-800">
                  <div>
                    <h2 className="text-lg font-bold text-white flex items-center gap-2">
                      <Youtube className="w-5 h-5 text-rose-500" />
                      Connect Your YouTube Channel (Supports Separate Account from Drive)
                    </h2>
                    <p className="text-sm text-slate-400 mt-1">
                      Connect your YouTube channel via official Google OAuth 2.0 to enable automatic video uploads, custom thumbnails, and native scheduled publishing.
                    </p>
                  </div>
                  <button
                    onClick={() => handleConnectGoogleOAuth('youtube')}
                    className="px-5 py-3 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 shrink-0 shadow-lg shadow-rose-600/25"
                  >
                    <Youtube className="w-4 h-4" />
                    Connect YouTube Channel (OAuth)
                  </button>
                </div>

                {/* Quick Connect YouTube Profile */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-5 items-end">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      YouTube Google Account Email
                    </label>
                    <input
                      type="email"
                      placeholder="e.g. my.youtube.channel@gmail.com"
                      value={quickYtEmail}
                      onChange={(e) => setQuickYtEmail(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      YouTube Channel Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Tech & AI Hindi Hub"
                      value={quickYtChannelName}
                      onChange={(e) => setQuickYtChannelName(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                    />
                  </div>
                  <button
                    onClick={() => handleQuickConnectAccount('youtube')}
                    className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Save / Switch YouTube Channel
                  </button>
                </div>

                {dash?.youtube_channel && (
                  <div className="mt-6 p-5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-rose-600/20 border border-rose-500/40 flex items-center justify-center text-rose-400 font-bold text-lg">
                        YT
                      </div>
                      <div>
                        <div className="font-bold text-base text-white">
                          {dash.youtube_channel.title}{' '}
                          <span className="text-xs text-emerald-400 font-normal">
                            ({dash.youtube_channel.custom_url})
                          </span>
                        </div>
                        <div className="text-xs text-slate-400 mt-1">
                          Channel ID: {dash.youtube_channel.channel_id} • Subscribers:{' '}
                          {dash.youtube_channel.subscriber_count} • Uploaded via AutoPilot:{' '}
                          {counts.uploaded + counts.scheduled}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 5: VIDEO MANAGER
             ======================================================== */}
          {activeTab === 'videos' && (
            <div className="space-y-6">
              <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-lg font-bold text-white">
                    Video Manager (Drive Downloaded & Local Videos)
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Preview videos, inspect metadata, or import a local video file from your computer to auto-generate SEO & schedule on YouTube.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <label className="cursor-pointer px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-2">
                    <UploadCloud className="w-4 h-4" />
                    Import Local Video (.mp4)
                    <input
                      type="file"
                      accept="video/*"
                      onChange={handleLocalVideoUpload}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {videos.map((v) => (
                  <div
                    key={v.id}
                    className="p-4 rounded-2xl bg-[#111827] border border-slate-800 flex flex-col justify-between gap-4"
                  >
                    <div className="flex gap-4">
                      {v.thumbnail?.image_url ? (
                        <img
                          src={v.thumbnail.image_url}
                          alt={v.title}
                          className="w-36 h-20 object-cover rounded-xl border border-slate-700 shrink-0"
                        />
                      ) : (
                        <div className="w-36 h-20 rounded-xl bg-slate-900 flex items-center justify-center shrink-0">
                          <Film className="w-6 h-6 text-slate-600" />
                        </div>
                      )}
                      <div className="min-w-0">
                        <div className="font-bold text-sm text-white line-clamp-2">{v.title}</div>
                        <div className="text-xs text-slate-400 mt-1">
                          {v.resolution} • {v.duration_seconds}s • Source: {v.source_type.toUpperCase()}
                        </div>
                        {v.schedule && (
                          <div className="text-xs text-blue-400 font-medium mt-1">
                            ⏰ Scheduled: {v.schedule.local_display} ({v.schedule.slot_time_label})
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-slate-800/80">
                      <span className="text-xs font-semibold text-emerald-400 uppercase">
                        Status: {v.status}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            selectVideoForStudios(v);
                            setActiveTab('seo');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200"
                        >
                          AI SEO
                        </button>
                        <button
                          onClick={() => {
                            selectVideoForStudios(v);
                            setActiveTab('thumbnail');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200"
                        >
                          Thumbnail
                        </button>
                        <button
                          onClick={async () => {
                            await fetch(`${API_BASE}/videos/${v.id}/upload-now`, {
                              method: 'POST',
                            });
                            await fetchAllData();
                            showNotice(`Uploaded "${v.title}" to YouTube!`);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs text-white font-medium"
                        >
                          Post Now
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 6: AI SEO STUDIO (GEMINI)
             ======================================================== */}
          {activeTab === 'seo' && (
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-5">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <h2 className="text-lg font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-400" />
                    AI SEO Studio (Powered by Google Gemini)
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Automatically generate high-CTR YouTube titles, descriptions, tags & hashtags in Hinglish, Hindi, Urdu, or English.
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <select
                    value={selectedVideoId || ''}
                    onChange={(e) => {
                      const v = videos.find((x) => x.id === Number(e.target.value));
                      if (v) selectVideoForStudios(v);
                    }}
                    className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  >
                    {videos.map((v) => (
                      <option key={v.id} value={v.id}>
                        #{v.id} - {v.title.slice(0, 40)}
                      </option>
                    ))}
                  </select>

                  <select
                    value={seoLanguage}
                    onChange={(e) => setSeoLanguage(e.target.value)}
                    className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  >
                    <option value="Hinglish">Hinglish (Hindi + English)</option>
                    <option value="English">English</option>
                    <option value="Hindi">Hindi</option>
                    <option value="Urdu">Urdu</option>
                  </select>

                  <button
                    onClick={handleGenerateSEO}
                    disabled={loading}
                    className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5"
                  >
                    <Sparkles className="w-4 h-4" /> Regenerate with AI
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">YouTube SEO Title</label>
                  <input
                    type="text"
                    value={seoTitle}
                    onChange={(e) => setSeoTitle(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Video Description (with Timestamps & Hashtags)
                  </label>
                  <textarea
                    rows={6}
                    value={seoDesc}
                    onChange={(e) => setSeoDesc(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Tags (comma separated)
                    </label>
                    <input
                      type="text"
                      value={seoTags}
                      onChange={(e) => setSeoTags(e.target.value)}
                      className="w-full px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Hashtags</label>
                    <input
                      type="text"
                      value={seoHashtags}
                      onChange={(e) => setSeoHashtags(e.target.value)}
                      className="w-full px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                </div>
                <button
                  onClick={handleSaveSEO}
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                >
                  Save & Approve SEO Metadata
                </button>
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 7: THUMBNAIL STUDIO
             ======================================================== */}
          {activeTab === 'thumbnail' && (
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-5 h-5 text-rose-500" />
                  1280x720 HD YouTube Thumbnail Studio
                </h2>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Select Video</label>
                  <select
                    value={selectedVideoId || ''}
                    onChange={(e) => {
                      const v = videos.find((x) => x.id === Number(e.target.value));
                      if (v) selectVideoForStudios(v);
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                  >
                    {videos.map((v) => (
                      <option key={v.id} value={v.id}>
                        #{v.id} - {v.title.slice(0, 45)}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Big Bold Headline Text
                  </label>
                  <input
                    type="text"
                    value={thumbHeadline}
                    onChange={(e) => setThumbHeadline(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Subheadline Bar</label>
                  <input
                    type="text"
                    value={thumbSubheadline}
                    onChange={(e) => setThumbSubheadline(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Top Badge Text</label>
                    <input
                      type="text"
                      value={thumbBadge}
                      onChange={(e) => setThumbBadge(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Accent Color</label>
                    <input
                      type="color"
                      value={thumbColor}
                      onChange={(e) => setThumbColor(e.target.value)}
                      className="w-full h-9 rounded-xl bg-slate-900 border border-slate-700 cursor-pointer"
                    />
                  </div>
                </div>
                <button
                  onClick={handleGenerateThumbnail}
                  disabled={loading}
                  className="w-full py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs"
                >
                  Render 1280x720 HD Thumbnail
                </button>
              </div>

              <div className="flex flex-col items-center justify-center bg-slate-900/90 border border-slate-800 rounded-xl p-4">
                <div className="text-xs text-slate-400 mb-2">Live 16:9 YouTube Thumbnail Preview</div>
                {selectedVideo?.thumbnail?.image_url ? (
                  <img
                    src={selectedVideo.thumbnail.image_url}
                    alt="Thumbnail Preview"
                    className="w-full max-w-md rounded-xl border border-slate-700 shadow-2xl"
                  />
                ) : (
                  <div className="text-xs text-slate-500 py-16">
                    Click "Render 1280x720 HD Thumbnail" to generate
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 8: AUTOMATION ENGINE
             ======================================================== */}
          {activeTab === 'automation' && (
            <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-6">
              <div>
                <h2 className="text-lg font-bold text-white">
                  Automation Engine (Full Auto vs Manual Controls)
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Control whether YT AutoPilot Pro runs 100% automatically from Google Drive to YouTube or waits for your manual review.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                {['Full Auto', 'SEO Auto', 'Upload Auto', 'Manual'].map((preset) => (
                  <button
                    key={preset}
                    onClick={async () => {
                      await fetch(`${API_BASE}/automation`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ preset_mode: preset }),
                      });
                      await fetchAllData();
                      showNotice(`Switched Automation Preset to: ${preset}`);
                    }}
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold border ${
                      dash?.automation?.preset_mode === preset
                        ? 'bg-rose-600 border-rose-500 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-300'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ========================================================
              TAB 9: APP SETUP & KEYS (UPLOAD CLIENT_SECRET.JSON)
             ======================================================== */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
              <div className="bg-[#111827] border border-slate-800 rounded-2xl p-6 space-y-5">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Settings className="w-5 h-5 text-blue-400" />
                  Easy In-App Google OAuth & Gemini AI Setup
                </h2>
                <p className="text-xs text-slate-400">
                  All keys are encrypted locally using AES/Fernet. You can upload your Google Cloud <code>client_secret.json</code> file with 1 click or paste your keys below.
                </p>

                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div>
                    <div className="text-sm font-bold text-white">
                      1-Click Upload <code>client_secret.json</code> (Recommended)
                    </div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      Download your Desktop/Web OAuth JSON from Google Cloud Console and upload it here to enable signing into <b>any Google Drive</b> and <b>any YouTube channel</b>.
                    </div>
                  </div>
                  <label className="cursor-pointer px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shrink-0">
                    Upload client_secret.json
                    <input
                      type="file"
                      accept=".json,application/json"
                      onChange={handleUploadClientSecretJson}
                      className="hidden"
                    />
                  </label>
                </div>

                <form onSubmit={handleSaveCredentials} className="space-y-4 pt-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">
                        Google OAuth Client ID
                      </label>
                      <input
                        type="text"
                        placeholder="xxxx.apps.googleusercontent.com"
                        value={clientIdInput}
                        onChange={(e) => setClientIdInput(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">
                        Google OAuth Client Secret ({creds?.google_client_secret_masked || 'Not set'})
                      </label>
                      <input
                        type="password"
                        placeholder="Enter to update Client Secret"
                        value={clientSecretInput}
                        onChange={(e) => setClientSecretInput(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Google Gemini API Key ({creds?.gemini_api_key_masked || 'Not set'})
                    </label>
                    <input
                      type="password"
                      placeholder="AIzaSy... (from aistudio.google.com)"
                      value={geminiKeyInput}
                      onChange={(e) => setGeminiKeyInput(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold"
                  >
                    Save & Encrypt Keys
                  </button>
                </form>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
