# YT AutoPilot Pro — Requirements Specification (Personal Edition)

## 1. Overview & Product Vision
**YT AutoPilot Pro (Personal Edition)** is a self-hosted, professional Windows 10/11 desktop application and FastAPI backend engineered specifically for personal YouTube channel automation and video scheduling.

Per product owner requirements:
- **Personal Use Edition**: No commercial license keys, hardware lockouts, or multi-tenant admin panels. The application opens directly into the workspace with full unlocked functionality.
- **Core Mission**: Effortlessly import videos (from local disk or Google Drive), generate high-converting SEO metadata and thumbnails via Google Gemini AI, and schedule/upload videos to YouTube reliably.

---

## 2. Functional Requirements

### 2.1 Video Scheduler & Calendar (Core Priority)
- Schedule single or bulk videos for specific dates, times, and timezones (e.g., `Asia/Kolkata`, `UTC`, `America/New_York`).
- **Smart Auto-Slot Scheduler**: Automatically queue pending videos into daily or weekly recurring time slots (e.g., daily at `18:00` local time) while respecting daily YouTube API upload limits.
- **Dual Scheduling Modes**:
  1. **YouTube Native Scheduling (`publishAt`)**: Uploads the video immediately as `private` with YouTube's official `status.publishAt` ISO-8601 UTC timestamp so YouTube publishes it automatically at the scheduled time even when the user's PC is turned off.
  2. **Background Worker Queue**: Holds the video in the local/cloud queue and triggers the upload job at the scheduled timestamp.
- Prevent duplicate schedules and support automatic retries on network failure.

### 2.2 YouTube Channel Integration (YouTube Data API v3)
- Official Google OAuth 2.0 desktop/web flow (`https://www.googleapis.com/auth/youtube.upload`, `https://www.googleapis.com/auth/youtube.readonly`).
- Display connected channel name, avatar, subscriber count, total views, and video count.
- **Resumable Video Uploads**: Chunked resumable uploads (`MediaFileUpload`) with real-time progress tracking, retry logic, and upload verification.
- Full metadata support: Title, Description, Tags, Category ID, Privacy (`private`, `unlisted`, `public`), `publishAt` schedule time, Playlist assignment, and custom Thumbnail upload.

### 2.3 Google Drive Integration (Google Drive API v3)
- Supports connecting a **separate Google account** for Google Drive from the YouTube channel account.
- Browse Drive folders, select source folders, scan for video files (`.mp4`, `.mov`, `.mkv`, `.webm`), track `drive_file_id` to prevent duplicate imports, and download videos locally for processing.

### 2.4 Video Manager
- Import local video files or folders, or sync from Google Drive.
- Automatic media inspection via `ffprobe`/`ffmpeg` (duration, resolution, FPS, file size, codec).
- Built-in HTML5 video preview, search, status filtering (`pending`, `ready_for_review`, `scheduled`, `uploading`, `uploaded`, `failed`), and duplicate detection via SHA-256 fingerprint / Drive File ID.

### 2.5 AI SEO Studio (Google Gemini API)
- Uses official `google-genai` SDK (`gemini-2.5-flash` / `gemini-2.5-pro`).
- Analyzes actual video metadata, extracted frames, and transcript/notes to generate:
  - High-CTR SEO Titles (with multiple options)
  - Structured Video Descriptions (with timestamps & call-to-action)
  - Tags, Keywords, Hashtags, and recommended YouTube Category
- Supports multi-language SEO output (**English, Hindi, Hinglish, Urdu, Spanish**).
- Allows manual editing and approval before scheduling.

### 2.6 Thumbnail Studio
- Extracts crisp 16:9 frames (`1280x720`) from the video using `ffmpeg` or accepts custom background images.
- Generates high-contrast YouTube thumbnails with bold customizable text overlays, badge highlights, and color accents using `Pillow`.
- Automatically uploads the approved thumbnail to YouTube when the video is uploaded.

### 2.7 Automation Engine
- **Presets**: `Full Auto`, `SEO Auto`, `Upload Auto`, `Manual`, and `Custom`.
- **Independent Step Controls (`AUTO` / `MANUAL`)**: Drive Scanning, Video Downloading, AI SEO Generation, Thumbnail Generation, Uploading, and Scheduling.
- **Global Controls**: `START`, `PAUSE`, `RESUME`, `STOP`.
- Configurable daily upload limit (default: `5 videos/day` to stay safely within Google's free 10,000-unit daily YouTube API quota).

### 2.8 Easy In-App Setup & Security
- Users never need to edit code. An **In-App Setup Wizard (App Settings)** allows entering Google OAuth Client ID/Secret and Gemini API Key directly in the UI, or loading them via `.env`.
- All OAuth refresh tokens and API secrets stored in the database are encrypted at rest using `Fernet` (AES-128-CBC + HMAC-SHA256).
