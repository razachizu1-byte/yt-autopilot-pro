# YT AutoPilot Pro — System Architecture

## 1. High-Level Architecture

```mermaid
flowchart LR
    subgraph Desktop["Windows Desktop App (Electron + React + TS)"]
        UI["Dark Dashboard UI"]
        Preload["Secure Preload Bridge (contextIsolation)"]
        Main["Electron Main Process"]
        UI <--> Preload <--> Main
    end

    subgraph Backend["Python FastAPI Backend & Worker"]
        API["FastAPI REST API (/api/v1)"]
        Scheduler["APScheduler / Cloud Scheduler Worker"]
        Vault["Fernet Token & Credential Vault"]
        Media["FFmpeg / Pillow Media Engine"]
        API --> Scheduler
        API --> Vault
        API --> Media
    end

    subgraph Storage["Persistence Layer"]
        DB[("SQLite (Local) / PostgreSQL (Cloud)")]
        FS["Local Media / Cloud Storage Staging"]
    end

    subgraph External["Official Google Cloud & AI APIs"]
        YTApi["YouTube Data API v3 (OAuth 2.0 + Resumable Upload)"]
        DriveApi["Google Drive API v3 (OAuth 2.0)"]
        Gemini["Google Gemini API (gemini-2.5-flash)"]
    end

    UI <-->|"HTTPS / Localhost REST"| API
    API <--> DB
    Scheduler <--> DB
    Media <--> FS
    API <--> YTApi
    API <--> DriveApi
    API <--> Gemini
```

---

## 2. Technology Stack

| Layer | Technology | Purpose |
| :--- | :--- | :--- |
| **Desktop Shell** | Electron + Electron Builder | Native Windows 10/11 `.exe` installer (NSIS + Portable), native file dialogs, tray/window management |
| **Frontend UI** | React 18 + TypeScript + Vite + Tailwind CSS + Lucide | Fast, responsive obsidian dark dashboard focused on scheduling & automation |
| **Backend API** | Python 3.11 + FastAPI + Uvicorn | REST endpoints, OAuth 2.0 callbacks, media processing, AI orchestration |
| **Database & ORM** | SQLAlchemy 2.0 + Alembic | Supports zero-config local **SQLite** out-of-the-box and **PostgreSQL** (`psycopg2`) for Cloud Run deployment |
| **Background Scheduler** | APScheduler + Cloud Scheduler webhook | Runs every 30 seconds locally (or via Cloud Scheduler in GCP) to process scheduled uploads and automation pipelines |
| **AI & Media** | `google-genai` + `ffmpeg` + `Pillow` | Video metadata inspection, frame extraction, Gemini SEO generation, 1280x720 thumbnail rendering |
| **Security** | `cryptography.fernet` + Google OAuth 2.0 | Symmetric encryption of OAuth tokens and API keys at rest; strict Electron `contextIsolation: true` and `nodeIntegration: false` |

---

## 3. Database Schema (SQLAlchemy Models)

1. **`app_credentials`**: Encrypted storage for Google OAuth Client ID/Secret and Gemini API Key configured via the UI or `.env`.
2. **`google_accounts`**: Stores connected Google accounts (`account_type`: `youtube` or `drive`), email, display name, avatar URL, and Fernet-encrypted OAuth access/refresh tokens.
3. **`youtube_channels`**: Connected YouTube channel ID, title, custom URL, subscriber/view/video counts, default category/privacy/language.
4. **`drive_folders`**: Monitored Google Drive folders (`folder_id`, `folder_name`, `auto_sync`, `last_scanned_at`).
5. **`videos`**: Master video table (`id`, `title`, `file_path`, `drive_file_id`, `file_hash`, `file_size_bytes`, `duration_seconds`, `resolution`, `status`, `youtube_video_id`, `youtube_url`, `error_message`).
6. **`seo_metadata`**: One-to-one with `videos` (`seo_title`, `description`, `tags_json`, `keywords_json`, `hashtags_json`, `category_id`, `playlist_id`, `language`, `ai_generated`, `approved`).
7. **`thumbnails`**: Associated with `videos` (`file_path`, `headline_text`, `subheadline_text`, `accent_color`, `template_style`, `uploaded_to_youtube`).
8. **`schedules`**: Video scheduling records (`video_id`, `scheduled_publish_at`, `timezone`, `privacy_status`, `use_youtube_publish_at`, `status`, `retry_count`, `last_error`).
9. **`upload_jobs`**: Tracks upload progress (`video_id`, `progress_percent`, `bytes_uploaded`, `status`, `started_at`, `completed_at`, `error_message`).
10. **`automation_settings`**: Global singleton settings (`preset_mode`, `engine_status`, `drive_scan_mode`, `download_mode`, `seo_mode`, `thumbnail_mode`, `upload_mode`, `schedule_mode`, `daily_upload_limit`, `default_schedule_times_json`, `default_timezone`).
11. **`activity_logs`**: Audit and operational logs (`level`, `category`, `message`, `video_id`, `details_json`, `created_at`).

---

## 4. How Scheduling Works (Local & Cloud)

1. **YouTube Native `publishAt` Mode (Recommended for Personal Desktop Use)**:
   - When you schedule a video for e.g. **Tomorrow at 6:00 PM IST**, YT AutoPilot Pro can upload the video *right now* while your PC is on, setting YouTube's official `status.privacyStatus = "private"` and `status.publishAt = "2026-11-16T12:30:00Z"`.
   - Once uploaded, **you can shut down your PC completely**—YouTube's servers automatically make the video Public at the exact scheduled minute!
2. **Deferred Queue Worker Mode**:
   - Holds the video file locally (or in Cloud Storage when deployed to Cloud Run) and starts the upload at the scheduled time via the background scheduler worker.
