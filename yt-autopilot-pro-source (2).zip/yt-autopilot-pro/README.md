# YT AutoPilot Pro — Personal Drive-to-YouTube Auto-Scheduler

**YT AutoPilot Pro** is a complete Windows 10/11 Desktop Application (Electron + React + TypeScript) and Python FastAPI Backend built to:
1. **Connect ANY Google Drive account inside the app** (and switch or add multiple Drive accounts anytime).
2. **Automatically scan & download new videos** from your selected Google Drive folders (preventing duplicates via `drive_file_id`).
3. **Generate AI SEO Metadata & 1280x720 HD Thumbnails** using Google Gemini (`gemini-2.5-flash`) + FFmpeg/Pillow in **Hinglish, Hindi, Urdu, or English**.
4. **Post & Schedule videos on YouTube at your exact Daily Time Slots** (e.g., `10:00`, `14:00`, `18:00`, `21:00` — *"kis-kis time post karna hai"*).

---

## How to Connect Any Google Drive & YouTube Inside the App

1. Open **YT AutoPilot Pro** and go to **App Setup & Keys** (bottom of the left sidebar).
2. Click **"Upload client_secret.json"** (or paste your Google OAuth Client ID & Secret from Google Cloud Console) and paste your **Gemini API Key** (from [Google AI Studio](https://aistudio.google.com/apikey)).
3. Go to **Google Drive Sync** tab &rarr; Click **"Sign In with Any Google Drive (OAuth)"** or use **Quick Connect** to link any Drive account and select your video folder(s).
4. Go to **YouTube Scheduler** tab &rarr; Add the daily times you want videos posted (e.g., `10:00`, `14:00`, `18:00`, `21:00`) and select your timezone (`Asia/Karachi`, `Asia/Kolkata`, etc.).
5. Click **"Sync Drive & Schedule Now"** (or leave **Full Auto** running) — the app will download new videos from Drive and schedule them on YouTube automatically!
