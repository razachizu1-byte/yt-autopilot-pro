@echo off
title YT AutoPilot Pro - Build Windows EXE Installer
echo ========================================================
echo   BUILDING WINDOWS EXE INSTALLER (NSIS + PORTABLE)
echo ========================================================
echo.

cd /d "%~dp0desktop"
if not exist "node_modules" (
    echo [1/2] Installing dependencies...
    call npm install
)

echo [2/2] Building Windows .exe Installer...
call npm run dist:win

echo.
echo ========================================================
echo   DONE! Check folder: desktop\release\
echo ========================================================
explorer release
pause
